#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <string>
#include <cmath>
#include <cstdint>
#include <vector>
#include <algorithm>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx9.h"

#define D3D9_RESET_INDEX 16
#define D3D9_ENDSCENE_INDEX 42
#define EXCEPTION_INFO_PTR      0x222DE28
#define GWORLD_OFFSET           0x22361A0

#define APAWN_WEAPON                0x940
#define ASGPLAYERCONTROLLER_SGPAWN  0x17a8

// AActor (inherited)
#define ACTOR_LOCATION              0x330
#define ACTOR_ROTATION              0x33c

// AWeapon
#define AWEAPON_BMELEEWEAPON        0x674

// ASGStandardMelee
#define SGMELEE_M_IMPACTPROXY            0x16ec
#define SGMELEE_M_CURRENTACTIVEPROXY     0x16fc
#define SGMELEE_M_MAXIMPACTPROXYHITDOT   0x1678
#define SGMELEE_M_IMPACTPROXY_ARCHETYPE  0x1648

// ASGMeleeImpactProxy
#define IMPACTPROXY_MELECOLLISIONCOMP    0x528
#define IMPACTPROXY_ATTACHMESH           0x534

// UPrimitiveComponent
#define PRIMCOMP_TRANSLATION             0x210
#define PRIMCOMP_SCALE                   0x228
#define PRIMCOMP_SCALE3D                 0x22c
#define PRIMCOMP_BOUNDSSCALE             0x238

// USkeletalMeshComponent
#define SKELCOMP_ATTACHMENTS             0x410

// FAttachment
#define FATTACHMENT_SIZE                 0x34
#define FATTACHMENT_COMPONENT            0x0
#define FATTACHMENT_BONENAME             0x8
#define FATTACHMENT_RELLOC               0x10
#define FATTACHMENT_RELROT               0x1c
#define FATTACHMENT_RELSCALE             0x28

// ASGWeapon fire timing
#define WEAPON_NEXTFIRETIME              0x13d0
#define WEAPON_SPREADRECOVERYTIME        0x13d8
#define WEAPON_FIREINTERVALMODIFIED      0x1574
#define WEAPON_FIREINTERVALAUGMENTMOD    0x1594

// AWeapon.FireInterval TArray
#define AWEAPON_FIREINTERVAL             0x610
#define AWEAPON_FIREINTERVAL_COUNT_OFF   0x618

// Ability cooldown
#define PC_DEFAULT_COOLDOWN_TEMPLATE   0x1800
#define CLASSCOOLDOWN_PLAYER_COOLDOWN  0x60
#define SETCOOLDOWN_ABILITY_COOLDOWNS  0x60
#define FSGABILCD_SIZE                 0x6c
#define FSGABILCD_MIN                  0x00
#define FSGABILCD_MAX                  0x04
#define FSGABILCD_TIMEOUT              0x0c
#define FSGABILCD_MAX_TIMEOUT          0x5c

// ============ VOTE-KICK DODGE OFFSETS ============
#define PC_ACTIVE_VOTE                    0x17C8
#define PC_M_SGPRI                        0x1BBC
#define PC_DEVELOPER_CONSOLE_ENABLED      0x1450
#define VOTE_M_BSYSTEMCALLED              0xC4
#define VOTE_M_TARGETTOKICKID             0xF4
#define PRI_PLAYER_ID                     0x558

#define VOTEKICK_TIMER_MS                 30000

// ============ ASGCamera / ACamera OFFSETS ============
#define ACAMERA_DEFAULTFOV                  0x540
#define ACAMERA_LOCKEDFOV                   0x548
#define ACAMERA_FADEAMOUNT                  0x560
#define ACAMERA_CAMERACACHE_TIMESTAMP       0x690
#define ACAMERA_POV_LOCATION                0x694
#define ACAMERA_POV_ROTATION_PITCH          0x6A0
#define ACAMERA_POV_ROTATION_YAW            0x6A4
#define ACAMERA_POV_ROTATION_ROLL           0x6A8
#define ACAMERA_POV_FOV                     0x6AC

#define ASGCAMERA_BUSECAMERACONTEXTS        0x80C
#define ASGCAMERA_DEFAULTCONTEXTNAME        0x810
#define ASGCAMERA_CAMERACONTEXTS            0x818
#define ASGCAMERA_DEFAULTCONTEXT            0x828
#define ASGCAMERA_ACTIVECONTEXT             0x830
#define ASGCAMERA_OLDPENDINGVIEWTARGET      0x838
#define ASGCAMERA_THIRDPERSON_DISTANCE      0x870
#define ASGCAMERA_THIRDPERSON_ROTATION      0x874
#define ASGCAMERA_FIRSTPERSON_DEBUGDIST     0x880
#define ASGCAMERA_FIRSTPERSON_DEBUGOFFSET   0x884
#define ASGCAMERA_FIRSTPERSON_DEBUGROT      0x890

// ============ MATH ============
struct FVector { float x, y, z; };
struct FRotator { int pitch, yaw, roll; };
struct Vector2 { float x, y; };

static const float UR_UNITS = 10430.378f;
static const float RAD_TO_UR = 65536.0f / (2.0f * 3.14159265f);
static const float UU_TO_DEG = 360.0f / 65536.0f;

// ============ SAFE MEMORY ============
bool ValidPtr(uintptr_t ptr) {
    return (ptr >= 0x10000 && ptr < 0x00007FFFFFFFFFFF);
}

bool IsReadable(uintptr_t addr, size_t size) {
    if (addr < 0x10000) return false;
    if (addr + size < addr) return false;
    MEMORY_BASIC_INFORMATION mbi;
    if (VirtualQuery((LPCVOID)addr, &mbi, sizeof(mbi)) == 0) return false;
    if (mbi.State != MEM_COMMIT) return false;
    if (mbi.Protect & PAGE_NOACCESS) return false;
    if (mbi.Protect & PAGE_GUARD) return false;
    return true;
}

template<typename T>
bool SafeRead(uintptr_t addr, T* out) {
    if (!IsReadable(addr, sizeof(T))) return false;
    *out = *(T*)addr;
    return true;
}

bool SafeWriteFloat(uintptr_t addr, float v) {
    if (!IsReadable(addr, sizeof(float))) return false;
    *(float*)addr = v;
    return true;
}

bool SafeWriteVector3(uintptr_t addr, float x, float y, float z) {
    if (!IsReadable(addr, sizeof(float) * 3)) return false;
    *(float*)(addr + 0x0) = x;
    *(float*)(addr + 0x4) = y;
    *(float*)(addr + 0x8) = z;
    return true;
}

bool SafeWriteInt(uintptr_t addr, int32_t v) {
    if (!IsReadable(addr, sizeof(int32_t))) return false;
    *(int32_t*)addr = v;
    return true;
}

bool SafeWriteBool(uintptr_t addr, bool v) {
    if (!IsReadable(addr, sizeof(bool))) return false;
    *(bool*)addr = v;
    return true;
}

bool SafeReadFVector(uintptr_t addr, FVector* out) {
    if (!IsReadable(addr, sizeof(FVector))) return false;
    *out = *(FVector*)addr;
    return true;
}

// ============ GLOBALS ============
uintptr_t g_Base = 0;
uintptr_t g_PC = 0;
uintptr_t g_LocalPawn = 0;
uintptr_t g_WorldInfo = 0;
bool bInit = false;
bool bShowMenu = false;
HWND hWindow = nullptr;
WNDPROC oWndProc = nullptr;

bool  g_NoRecoil          = true;
bool  g_NoSpread          = true;
float g_CustomSpreadValue = 0.0f;

bool  g_MeleeRange         = false;
float g_MeleeBoundsScale   = 2.3f;
bool  g_MeleeVisualScale   = false;
bool  g_MeleeWideAngle     = false;
float g_MeleeHitDot        = -1.0f;
bool  g_MeleePushForward   = true;
float g_MeleeForwardOffset = 2.3f;

bool  g_FastMelee               = false;
float g_MeleeFireInterval       = 0.05f;
bool  g_FastMeleeForceNextFire  = true;

bool  g_FastCooldowns      = false;
float g_CooldownMultiplier = 0.25f;

// ============ AUTO SHOOT ============
bool  g_AutoShootEnabled    = false;
bool  g_AutoShootToggleMode = false;
int   g_AutoShootKey        = VK_XBUTTON1;
int   g_AutoShootDelay      = 50;
bool  g_AutoShootTeamCheck  = true;
DWORD g_LastAutoShootShot   = 0;

// ============ VOTE-KICK DODGE ============
bool      g_VoteKickDodge        = false;
bool      g_VoteKickDodgeFired   = false;
uintptr_t g_LastVoteMsg          = 0;
int32_t   g_LastVoteTargetId     = -1;
bool      g_DodgeOnPlayerKick    = true;

static bool     g_DodgeFiredThisVote = false;
static uintptr_t g_LatchedVoteMsg    = 0;
static int32_t   g_LatchedTargetId   = -1;

DWORD g_DodgeFiredAtTick     = 0;
bool  g_ShowRejoinTimer      = true;

static volatile bool g_ConsoleBusy = false;
static DWORD         g_ConsoleBlockUntil = 0;

// ============ TP ============
bool  g_TpEnabled   = false;
int   g_TpMode      = 0;
int   g_TpKey       = VK_RBUTTON;
float g_TpCooldown  = 0.5f;
DWORD g_LastTpTime  = 0;
uintptr_t g_CurrentTpTarget = 0;
uintptr_t g_RandomEnemyTarget = 0;
bool  g_TpWasKeyDown = false;
bool  g_TpActive     = false;
DWORD g_LastLocationCheck = 0;

bool  g_TpStepped       = true;
int   g_TpStepCount     = 6;
int   g_TpStepDelayMs   = 60;
float g_TpMaxStepUnits  = 400.0f;
bool  g_TpFaceTarget    = true;
float g_TpAimHeightOffset = 40.0f;
bool  g_TpForceSync     = true;
bool  g_TpIncludeTeammates = false;

static bool     g_StepActive      = false;
static FVector  g_StepTarget      = {0, 0, 0};
static int      g_StepsRemaining  = 0;
static DWORD    g_LastStepTick    = 0;
static uintptr_t g_StepPawn       = 0;

bool  g_FovCircleEnabled = true;
float g_FovCircleRadius  = 150.0f;

// ============ ESP ============
bool g_EspEnabled  = true;
bool g_EspBox      = true;
bool g_EspHealth   = true;
bool g_EspNames    = true;
bool g_EspTracers  = true;
bool g_EspTeammates = true;
bool g_EspDownedTeammates = true;
bool g_TeamCheck   = true;

struct CachedPawn {
    ImVec2 screenCenter;
    ImVec2 sBase;
    ImVec2 sHead;
    ImVec2 boxMin;
    ImVec2 boxMax;
    int hp;
    int hpMax;
    int team;
    bool isEnemy;
    bool isDowned;
    char name[64];
    uintptr_t pawnPtr;
};
std::vector<CachedPawn> g_PawnCache;

struct PawnNameCache { uintptr_t pawnPtr; char name[64]; };
std::vector<PawnNameCache> g_PawnNames;

std::vector<uintptr_t> g_AllEnemies;
std::vector<uintptr_t> g_RandomTpPool;

IDirect3DDevice9* g_pDevice = nullptr;

// ============ CAMERA DEBUG ============
uintptr_t g_SGCamera = 0;
char      g_CameraDump[8192] = { 0 };

// ============ ALWAYS LOOK AT GROUND ============
bool    g_LookGroundEnabled    = false;
float   g_LookGroundInterval   = 1.0f;    // seconds between forced re-applies
int32_t g_LookGroundPitch      = -16000;  // UU pitch for straight down (from your dump)
bool    g_LookGroundCaptured   = false;

// Recoil snap — snap instantly if pitch rises above this threshold (game pushes view up)
bool    g_LookGroundRecoilSnap = true;
int32_t g_LookGroundRecoilTrig = -15500;  // anything above (higher than) this = snapped back

// Live status for UI
int32_t g_LastSeenPitch        = 0;
DWORD   g_LastLookGroundApply  = 0;
int     g_LookGroundApplyCount = 0;

// ============ CONFIG ============
void SaveConfig() {
    FILE* f;
    if (fopen_s(&f, "config.ini", "w") == 0) {
        fprintf(f, "NoRecoil=%d\n", g_NoRecoil);
        fprintf(f, "NoSpread=%d\n", g_NoSpread);
        fprintf(f, "CustomSpreadValue=%.4f\n", g_CustomSpreadValue);
        fprintf(f, "MeleeRange=%d\n", g_MeleeRange);
        fprintf(f, "MeleeBoundsScale=%.2f\n", g_MeleeBoundsScale);
        fprintf(f, "MeleeVisualScale=%d\n", g_MeleeVisualScale);
        fprintf(f, "MeleeWideAngle=%d\n", g_MeleeWideAngle);
        fprintf(f, "MeleeHitDot=%.2f\n", g_MeleeHitDot);
        fprintf(f, "MeleePushForward=%d\n", g_MeleePushForward);
        fprintf(f, "MeleeForwardOffset=%.2f\n", g_MeleeForwardOffset);
        fprintf(f, "FastMelee=%d\n", g_FastMelee);
        fprintf(f, "MeleeFireInterval=%.4f\n", g_MeleeFireInterval);
        fprintf(f, "FastMeleeForceNextFire=%d\n", g_FastMeleeForceNextFire);
        fprintf(f, "FastCooldowns=%d\n", g_FastCooldowns);
        fprintf(f, "CooldownMultiplier=%.2f\n", g_CooldownMultiplier);
        fprintf(f, "TpEnabled=%d\n", g_TpEnabled);
        fprintf(f, "TpMode=%d\n", g_TpMode);
        fprintf(f, "TpKey=%d\n", g_TpKey);
        fprintf(f, "TpCooldown=%.2f\n", g_TpCooldown);
        fprintf(f, "TpStepped=%d\n", g_TpStepped);
        fprintf(f, "TpStepCount=%d\n", g_TpStepCount);
        fprintf(f, "TpStepDelayMs=%d\n", g_TpStepDelayMs);
        fprintf(f, "TpMaxStepUnits=%.1f\n", g_TpMaxStepUnits);
        fprintf(f, "TpFaceTarget=%d\n", g_TpFaceTarget);
        fprintf(f, "TpAimHeightOffset=%.2f\n", g_TpAimHeightOffset);
        fprintf(f, "TpForceSync=%d\n", g_TpForceSync);
        fprintf(f, "TpIncludeTeammates=%d\n", g_TpIncludeTeammates);
        fprintf(f, "FovCircle=%d\n", g_FovCircleEnabled);
        fprintf(f, "FovRadius=%.2f\n", g_FovCircleRadius);
        fprintf(f, "EspEnabled=%d\n", g_EspEnabled);
        fprintf(f, "EspBox=%d\n", g_EspBox);
        fprintf(f, "EspHealth=%d\n", g_EspHealth);
        fprintf(f, "EspNames=%d\n", g_EspNames);
        fprintf(f, "EspTracers=%d\n", g_EspTracers);
        fprintf(f, "EspTeam=%d\n", g_EspTeammates);
        fprintf(f, "EspDowned=%d\n", g_EspDownedTeammates);
        fprintf(f, "TeamCheck=%d\n", g_TeamCheck);
        fprintf(f, "VoteKickDodge=%d\n", g_VoteKickDodge);
        fprintf(f, "DodgeOnPlayerKick=%d\n", g_DodgeOnPlayerKick);
        fprintf(f, "ShowRejoinTimer=%d\n", g_ShowRejoinTimer);
        fprintf(f, "AutoShoot=%d\n", g_AutoShootEnabled);
        fprintf(f, "AutoShootToggle=%d\n", g_AutoShootToggleMode);
        fprintf(f, "AutoShootKey=%d\n", g_AutoShootKey);
        fprintf(f, "AutoShootDelay=%d\n", g_AutoShootDelay);
        fprintf(f, "AutoShootTeamCheck=%d\n", g_AutoShootTeamCheck);
        fprintf(f, "LookGround=%d\n", g_LookGroundEnabled);
        fprintf(f, "LookGroundInterval=%.2f\n", g_LookGroundInterval);
        fprintf(f, "LookGroundPitch=%d\n", g_LookGroundPitch);
        fprintf(f, "LookGroundRecoilSnap=%d\n", g_LookGroundRecoilSnap);
        fprintf(f, "LookGroundRecoilTrig=%d\n", g_LookGroundRecoilTrig);
        fclose(f);
    }
}

void LoadConfig() {
    FILE* f;
    if (fopen_s(&f, "config.ini", "r") == 0) {
        char line[256];
        while (fgets(line, sizeof(line), f)) {
            if (strncmp(line, "NoRecoil=", 9) == 0) g_NoRecoil = atoi(line + 9);
            else if (strncmp(line, "NoSpread=", 9) == 0) g_NoSpread = atoi(line + 9);
            else if (strncmp(line, "CustomSpreadValue=", 18) == 0) g_CustomSpreadValue = (float)atof(line + 18);
            else if (strncmp(line, "MeleeRange=", 11) == 0)       g_MeleeRange       = atoi(line + 11);
            else if (strncmp(line, "MeleeBoundsScale=", 17) == 0) g_MeleeBoundsScale = (float)atof(line + 17);
            else if (strncmp(line, "MeleeVisualScale=", 17) == 0) g_MeleeVisualScale = atoi(line + 17);
            else if (strncmp(line, "MeleeWideAngle=", 15) == 0)   g_MeleeWideAngle   = atoi(line + 15);
            else if (strncmp(line, "MeleeHitDot=", 12) == 0)      g_MeleeHitDot      = (float)atof(line + 12);
            else if (strncmp(line, "MeleePushForward=", 17) == 0) g_MeleePushForward = atoi(line + 17);
            else if (strncmp(line, "MeleeForwardOffset=", 19) == 0) g_MeleeForwardOffset = (float)atof(line + 19);
            else if (strncmp(line, "FastMelee=", 10) == 0)        g_FastMelee        = atoi(line + 10);
            else if (strncmp(line, "MeleeFireInterval=", 18) == 0) g_MeleeFireInterval = (float)atof(line + 18);
            else if (strncmp(line, "FastMeleeForceNextFire=", 23) == 0) g_FastMeleeForceNextFire = atoi(line + 23);
            else if (strncmp(line, "FastCooldowns=", 14) == 0)    g_FastCooldowns    = atoi(line + 14);
            else if (strncmp(line, "CooldownMultiplier=", 19) == 0) g_CooldownMultiplier = (float)atof(line + 19);
            else if (strncmp(line, "TpEnabled=", 10) == 0)  g_TpEnabled  = atoi(line + 10);
            else if (strncmp(line, "TpMode=", 7) == 0)      g_TpMode     = atoi(line + 7);
            else if (strncmp(line, "TpKey=", 6) == 0)       g_TpKey      = atoi(line + 6);
            else if (strncmp(line, "TpCooldown=", 11) == 0) g_TpCooldown = (float)atof(line + 11);
            else if (strncmp(line, "TpStepped=", 10) == 0)  g_TpStepped  = atoi(line + 10);
            else if (strncmp(line, "TpStepCount=", 12) == 0) g_TpStepCount = atoi(line + 12);
            else if (strncmp(line, "TpStepDelayMs=", 14) == 0) g_TpStepDelayMs = atoi(line + 14);
            else if (strncmp(line, "TpMaxStepUnits=", 15) == 0) g_TpMaxStepUnits = (float)atof(line + 15);
            else if (strncmp(line, "TpFaceTarget=", 13) == 0) g_TpFaceTarget = atoi(line + 13);
            else if (strncmp(line, "TpAimHeightOffset=", 18) == 0) g_TpAimHeightOffset = (float)atof(line + 18);
            else if (strncmp(line, "TpForceSync=", 12) == 0) g_TpForceSync = atoi(line + 12);
            else if (strncmp(line, "TpIncludeTeammates=", 19) == 0) g_TpIncludeTeammates = atoi(line + 19);
            else if (strncmp(line, "FovCircle=", 10) == 0)  g_FovCircleEnabled = atoi(line + 10);
            else if (strncmp(line, "FovRadius=", 10) == 0)  g_FovCircleRadius  = (float)atof(line + 10);
            else if (strncmp(line, "EspEnabled=", 11) == 0) g_EspEnabled = atoi(line + 11);
            else if (strncmp(line, "EspBox=", 7) == 0)      g_EspBox     = atoi(line + 7);
            else if (strncmp(line, "EspHealth=", 10) == 0)  g_EspHealth  = atoi(line + 10);
            else if (strncmp(line, "EspNames=", 9) == 0)    g_EspNames   = atoi(line + 9);
            else if (strncmp(line, "EspTracers=", 11) == 0) g_EspTracers = atoi(line + 11);
            else if (strncmp(line, "EspTeam=", 8) == 0)     g_EspTeammates = atoi(line + 8);
            else if (strncmp(line, "EspDowned=", 10) == 0)  g_EspDownedTeammates = atoi(line + 10);
            else if (strncmp(line, "TeamCheck=", 10) == 0)  g_TeamCheck = atoi(line + 10);
            else if (strncmp(line, "VoteKickDodge=", 14) == 0)      g_VoteKickDodge = atoi(line + 14);
            else if (strncmp(line, "DodgeOnPlayerKick=", 18) == 0)  g_DodgeOnPlayerKick = atoi(line + 18);
            else if (strncmp(line, "ShowRejoinTimer=", 16) == 0)    g_ShowRejoinTimer = atoi(line + 16);
            else if (strncmp(line, "AutoShootTeamCheck=", 19) == 0) g_AutoShootTeamCheck = atoi(line + 19);
            else if (strncmp(line, "AutoShootDelay=", 15) == 0)     g_AutoShootDelay     = atoi(line + 15);
            else if (strncmp(line, "AutoShootKey=", 13) == 0)       g_AutoShootKey       = atoi(line + 13);
            else if (strncmp(line, "AutoShootToggle=", 16) == 0)    g_AutoShootToggleMode = atoi(line + 16);
            else if (strncmp(line, "AutoShoot=", 10) == 0)          g_AutoShootEnabled   = atoi(line + 10);
            else if (strncmp(line, "LookGround=", 11) == 0)         g_LookGroundEnabled = atoi(line + 11);
            else if (strncmp(line, "LookGroundInterval=", 19) == 0) g_LookGroundInterval = (float)atof(line + 19);
            else if (strncmp(line, "LookGroundPitch=", 16) == 0)    g_LookGroundPitch = atoi(line + 16);
            else if (strncmp(line, "LookGroundRecoilSnap=", 21) == 0) g_LookGroundRecoilSnap = atoi(line + 21);
            else if (strncmp(line, "LookGroundRecoilTrig=", 21) == 0) g_LookGroundRecoilTrig = atoi(line + 21);
        }
        fclose(f);
    }
}

typedef HRESULT(WINAPI* EndScene_t)(IDirect3DDevice9*);
typedef HRESULT(WINAPI* Reset_t)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);
EndScene_t oEndScene = nullptr;
Reset_t    oReset    = nullptr;

// ============ HELPERS ============
int GetPawnTeam(uintptr_t pawn) {
    if (!ValidPtr(pawn)) return -1;
    uintptr_t pri = 0;
    if (!SafeRead(pawn + 0x3F0, &pri) || !ValidPtr(pri)) {
        int t = 0;
        if (SafeRead(pawn + 0x1DF0, &t)) return t;
        return -1;
    }
    int t = 0;
    if (!SafeRead(pri + 0xECC, &t)) return -1;
    return t;
}

bool IsPawnAlive(uintptr_t pawn) {
    if (!ValidPtr(pawn)) return false;
    int hp = 0;
    if (!SafeRead(pawn + 0x81C, &hp)) return false;
    return hp > 0;
}

bool IsPawnDowned(uintptr_t pawn) {
    if (!ValidPtr(pawn)) return false;
    int hp = 0;
    SafeRead(pawn + 0x81C, &hp);
    if (hp > 0) return false;

    uintptr_t incapMove = 0;
    if (SafeRead(pawn + 0x1c2c, &incapMove) && ValidPtr(incapMove)) {
        uint8_t incapState = 0;
        if (SafeRead(incapMove + 0x5a8, &incapState)) {
            if (incapState == 2 || incapState == 3) return true;
        }
    }
    float bleedOutTime = 0.0f;
    if (SafeRead(pawn + 0x1efc, &bleedOutTime) && bleedOutTime > 0.0f && bleedOutTime < 99999.0f)
        return true;
    bool bIncapped = false;
    if (SafeRead(pawn + 0x1bb8, &bIncapped) && bIncapped) return true;
    return false;
}

void ReadFString(uintptr_t stringAddr, char* buffer, int maxLen) {
    buffer[0] = '\0';
    if (!ValidPtr(stringAddr) || maxLen <= 0) return;

    wchar_t* data = nullptr;
    int count = 0, max = 0;
    if (!SafeRead(stringAddr, &data)) return;
    if (!SafeRead(stringAddr + 8, &count)) return;
    if (!SafeRead(stringAddr + 12, &max)) return;
    if (!ValidPtr((uintptr_t)data)) return;
    if (count <= 0 || count > 256) return;
    if (max <= 0 || max > 512) return;
    if (count > max) return;

    int len = (count < maxLen - 1) ? count : maxLen - 1;
    for (int i = 0; i < len; i++) {
        wchar_t wc = data[i];
        if (wc == 0) break;
        buffer[i] = (wc > 0 && wc < 128) ? (char)wc : '?';
    }
    buffer[len] = '\0';
}

void TeleportPlayer(uintptr_t pawn, FVector location) {
    if (!ValidPtr(pawn)) return;
    if (!IsReadable(pawn + ACTOR_LOCATION, sizeof(FVector))) return;
    *(FVector*)(pawn + ACTOR_LOCATION) = location;
}

void FaceTowards(uintptr_t actor, FVector fromPos, FVector targetPos) {
    if (!ValidPtr(actor)) return;

    float dx = targetPos.x - fromPos.x;
    float dy = targetPos.y - fromPos.y;
    float dz = targetPos.z - fromPos.z;

    float horiz = sqrtf(dx*dx + dy*dy);
    if (horiz < 0.001f) return;

    int32_t yaw   = (int32_t)(atan2f(dy, dx) * RAD_TO_UR);
    int32_t pitch = (int32_t)(atan2f(dz, horiz) * RAD_TO_UR);

    if (IsReadable(actor + ACTOR_ROTATION, 12)) {
        *(int32_t*)(actor + ACTOR_ROTATION + 0) = pitch;
        *(int32_t*)(actor + ACTOR_ROTATION + 4) = yaw;
        *(int32_t*)(actor + ACTOR_ROTATION + 8) = 0;
    }
}

void OrientAtTarget(uintptr_t localPawn, FVector targetLoc) {
    if (!g_TpFaceTarget) return;
    if (!ValidPtr(localPawn)) return;

    FVector myLoc;
    if (!SafeReadFVector(localPawn + ACTOR_LOCATION, &myLoc)) return;

    FVector aim = targetLoc;
    aim.z += g_TpAimHeightOffset;

    FaceTowards(g_PC, myLoc, aim);
    FaceTowards(localPawn, myLoc, aim);
}

void BeginSteppedTP(uintptr_t localPawn, FVector target) {
    if (!ValidPtr(localPawn)) return;

    FVector myLoc;
    if (!SafeReadFVector(localPawn + ACTOR_LOCATION, &myLoc)) return;

    float dx = target.x - myLoc.x;
    float dy = target.y - myLoc.y;
    float dz = target.z - myLoc.z;
    float dist = sqrtf(dx*dx + dy*dy + dz*dz);

    if (dist < 50.0f) {
        TeleportPlayer(localPawn, target);
        OrientAtTarget(localPawn, target);
        g_StepActive = false;
        return;
    }

    int steps = g_TpStepCount;
    if (steps < 2) steps = 2;
    float needed = dist / g_TpMaxStepUnits;
    if ((int)needed > steps) steps = (int)needed + 1;

    g_StepPawn        = localPawn;
    g_StepTarget      = target;
    g_StepsRemaining  = steps;
    g_StepActive      = true;
    g_LastStepTick    = 0;

    OrientAtTarget(localPawn, target);
}

void UpdateSteppedTP() {
    if (!g_StepActive) return;
    if (!ValidPtr(g_StepPawn)) { g_StepActive = false; return; }

    DWORD now = GetTickCount();
    if (g_LastStepTick && (now - g_LastStepTick) < (DWORD)g_TpStepDelayMs) return;
    g_LastStepTick = now;

    FVector cur;
    if (!SafeReadFVector(g_StepPawn + ACTOR_LOCATION, &cur)) { g_StepActive = false; return; }

    float dx = g_StepTarget.x - cur.x;
    float dy = g_StepTarget.y - cur.y;
    float dz = g_StepTarget.z - cur.z;
    float dist = sqrtf(dx*dx + dy*dy + dz*dz);

    if (dist < 50.0f || g_StepsRemaining <= 1) {
        TeleportPlayer(g_StepPawn, g_StepTarget);
        OrientAtTarget(g_StepPawn, g_StepTarget);
        g_StepActive = false;
        return;
    }

    float stepLen = dist / (float)g_StepsRemaining;
    if (stepLen > g_TpMaxStepUnits) stepLen = g_TpMaxStepUnits;
    if (stepLen < 30.0f) stepLen = 30.0f;

    FVector next;
    next.x = cur.x + (dx / dist) * stepLen;
    next.y = cur.y + (dy / dist) * stepLen;
    next.z = cur.z + (dz / dist) * stepLen;

    TeleportPlayer(g_StepPawn, next);
    OrientAtTarget(g_StepPawn, next);
    g_StepsRemaining--;
}

void PerformTP(uintptr_t localPawn, FVector target) {
    if (g_TpStepped) {
        BeginSteppedTP(localPawn, target);
    } else {
        TeleportPlayer(localPawn, target);
        OrientAtTarget(localPawn, target);
    }
}

// ============ WORLD TO SCREEN ============
struct Matrix4x4 { float M[4][4]; };
Matrix4x4 g_ViewProj;
bool g_ViewProjValid = false;

static void MatrixMultiply(const Matrix4x4& a, const Matrix4x4& b, Matrix4x4& out) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            out.M[i][j] = a.M[i][0]*b.M[0][j] + a.M[i][1]*b.M[1][j] +
                          a.M[i][2]*b.M[2][j] + a.M[i][3]*b.M[3][j];
        }
    }
}

static void BuildViewProj() {
    g_ViewProjValid = false;
    if (!ValidPtr(g_PC)) return;

    uintptr_t m_SGPawn = 0, m_ViewTarget = 0, m_SGCamera = 0;
    if (!SafeRead(g_PC + 0x17a8, &m_SGPawn) || !ValidPtr(m_SGPawn)) return;
    if (!SafeRead(m_SGPawn + 0x1df8, &m_ViewTarget) || !ValidPtr(m_ViewTarget)) return;
    if (!SafeRead(m_ViewTarget + 0x18e4, &m_SGCamera) || !ValidPtr(m_SGCamera)) return;

    FVector pos;
    int32_t int_pitch = 0, int_yaw = 0, int_roll = 0;
    float fov = 0.0f;
    if (!SafeReadFVector(m_SGCamera + ACAMERA_POV_LOCATION, &pos)) return;
    SafeRead(m_SGCamera + ACAMERA_POV_ROTATION_PITCH, &int_pitch);
    SafeRead(m_SGCamera + ACAMERA_POV_ROTATION_YAW,   &int_yaw);
    SafeRead(m_SGCamera + ACAMERA_POV_ROTATION_ROLL,  &int_roll);
    SafeRead(m_SGCamera + ACAMERA_POV_FOV,            &fov);

    if (fov < 1.0f || fov > 170.0f) fov = 90.0f;

    float pitch = (int_pitch * 360.0f / 65536.0f) * 3.14159265f / 180.0f;
    float yaw   = (int_yaw   * 360.0f / 65536.0f) * 3.14159265f / 180.0f;
    float roll  = (int_roll  * 360.0f / 65536.0f) * 3.14159265f / 180.0f;

    float cp = cosf(pitch), sp = sinf(pitch);
    float cy = cosf(yaw),   sy = sinf(yaw);
    float cr = cosf(roll),  sr = sinf(roll);

    FVector fwd = { cp * cy, cp * sy, sp };

    FVector worldUp = { 0, 0, 1 };
    FVector right = { worldUp.y*fwd.z - worldUp.z*fwd.y,
                      worldUp.z*fwd.x - worldUp.x*fwd.z,
                      worldUp.x*fwd.y - worldUp.y*fwd.x };
    float rlen = sqrtf(right.x*right.x + right.y*right.y + right.z*right.z);
    if (rlen < 0.0001f) return;
    right.x /= rlen; right.y /= rlen; right.z /= rlen;

    FVector up = { fwd.y*right.z - fwd.z*right.y,
                   fwd.z*right.x - fwd.x*right.z,
                   fwd.x*right.y - fwd.y*right.x };

    FVector rolledUp = { up.x*cr - right.x*sr,
                         up.y*cr - right.y*sr,
                         up.z*cr - right.z*sr };

    Matrix4x4 view = {};
    view.M[0][0] = right.x;   view.M[0][1] = right.y;   view.M[0][2] = right.z;   view.M[0][3] = -(right.x*pos.x + right.y*pos.y + right.z*pos.z);
    view.M[1][0] = rolledUp.x;view.M[1][1] = rolledUp.y;view.M[1][2] = rolledUp.z;view.M[1][3] = -(rolledUp.x*pos.x + rolledUp.y*pos.y + rolledUp.z*pos.z);
    view.M[2][0] = fwd.x;     view.M[2][1] = fwd.y;     view.M[2][2] = fwd.z;     view.M[2][3] = -(fwd.x*pos.x + fwd.y*pos.y + fwd.z*pos.z);
    view.M[3][0] = 0;         view.M[3][1] = 0;         view.M[3][2] = 0;         view.M[3][3] = 1;

    float aspect = 16.0f / 9.0f;
    if (g_pDevice) {
        D3DVIEWPORT9 vp;
        if (SUCCEEDED(g_pDevice->GetViewport(&vp)) && vp.Height > 0)
            aspect = (float)vp.Width / (float)vp.Height;
    }
    float fovRad = fov * 3.14159265f / 180.0f;
    float yScale = 1.0f / tanf(fovRad * 0.5f);
    float xScale = yScale / aspect;

    Matrix4x4 proj = {};
    proj.M[0][0] = xScale;
    proj.M[1][1] = yScale;
    proj.M[2][2] = 1000.0f / (1000.0f - 0.01f);
    proj.M[2][3] = -0.01f * 1000.0f / (1000.0f - 0.01f);
    proj.M[3][2] = 1.0f;
    proj.M[3][3] = 0;

    MatrixMultiply(view, proj, g_ViewProj);
    g_ViewProjValid = true;
}

bool WorldToScreen(const FVector& world, Vector2& out) {
    if (!g_ViewProjValid || !g_pDevice) return false;
    D3DVIEWPORT9 vp;
    if (FAILED(g_pDevice->GetViewport(&vp)) || vp.Height == 0) return false;
    float sw = (float)vp.Width, sh = (float)vp.Height;

    const Matrix4x4& m = g_ViewProj;
    float cx = m.M[0][0]*world.x + m.M[0][1]*world.y + m.M[0][2]*world.z + m.M[0][3];
    float cy = m.M[1][0]*world.x + m.M[1][1]*world.y + m.M[1][2]*world.z + m.M[1][3];
    float cw = m.M[3][0]*world.x + m.M[3][1]*world.y + m.M[3][2]*world.z + m.M[3][3];
    if (cw <= 0.001f) return false;

    float invW = 1.0f / cw;
    float ndcX = cx * invW;
    float ndcY = cy * invW;

    out.x = (sw * 0.5f) + (ndcX * sw * 0.5f);
    out.y = (sh * 0.5f) - (ndcY * sh * 0.5f);
    return true;
}

// ============ PAWN ITERATION ============
template<typename Fn>
void ForEachPawn(Fn fn) {
    uintptr_t world = 0;
    if (!SafeRead(g_Base + GWORLD_OFFSET, &world) || !ValidPtr(world)) return;
    uintptr_t level = 0;
    if (!SafeRead(world + 0x80, &level) || !ValidPtr(level)) return;
    uintptr_t worldInfoPtr = 0;
    if (!SafeRead(level + 0x60, &worldInfoPtr) || !ValidPtr(worldInfoPtr)) return;
    uintptr_t worldInfo = 0;
    if (!SafeRead(worldInfoPtr, &worldInfo) || !ValidPtr(worldInfo)) return;
    g_WorldInfo = worldInfo;

    uintptr_t currentPawn = 0;
    if (!SafeRead(worldInfo + 0x884, &currentPawn)) return;

    int safety = 0;
    while (ValidPtr(currentPawn) && safety++ < 400) {
        fn(currentPawn);
        uintptr_t next = 0;
        if (!SafeRead(currentPawn + 0x710, &next)) break;
        currentPawn = next;
    }
}

void BuildEnemyLists() {
    g_AllEnemies.clear();
    g_RandomTpPool.clear();
    if (!ValidPtr(g_LocalPawn)) return;

    int myTeam = GetPawnTeam(g_LocalPawn);
    if (myTeam == -1) return;

    ForEachPawn([&](uintptr_t p) {
        if (p == g_LocalPawn) return;
        if (!IsPawnAlive(p)) return;

        int t = GetPawnTeam(p);
        if (t == -1) return;

        bool isTeammate = (t == myTeam);
        if (IsPawnDowned(p)) return;

        FVector loc;
        if (!SafeReadFVector(p + ACTOR_LOCATION, &loc)) return;
        if (loc.x == 0.0f && loc.y == 0.0f && loc.z == 0.0f) return;

        if (!isTeammate) {
            g_AllEnemies.push_back(p);
        }

        if (!isTeammate || g_TpIncludeTeammates) {
            g_RandomTpPool.push_back(p);
        }
    });
}

// ============ MELEE HELPERS ============
static void ApplyMeleeForwardOffset(uintptr_t proxy, uintptr_t collComp, float forwardOffset) {
    if (!ValidPtr(proxy) || !ValidPtr(collComp)) return;

    uintptr_t attachMesh = 0;
    if (SafeRead(proxy + IMPACTPROXY_ATTACHMESH, &attachMesh) && ValidPtr(attachMesh)) {
        uintptr_t attData = 0;
        int32_t   attCount = 0;
        if (SafeRead(attachMesh + SKELCOMP_ATTACHMENTS,       &attData)  &&
            SafeRead(attachMesh + SKELCOMP_ATTACHMENTS + 0x8, &attCount) &&
            ValidPtr(attData) && attCount > 0 && attCount < 64)
        {
            for (int i = 0; i < attCount; i++) {
                uintptr_t entry = attData + (i * FATTACHMENT_SIZE);
                uintptr_t entryComp = 0;
                if (!SafeRead(entry + FATTACHMENT_COMPONENT, &entryComp)) continue;
                if (entryComp != collComp) continue;

                FVector relLoc;
                if (SafeReadFVector(entry + FATTACHMENT_RELLOC, &relLoc)) {
                    relLoc.x = forwardOffset;
                    SafeWriteVector3(entry + FATTACHMENT_RELLOC,
                                     relLoc.x, relLoc.y, relLoc.z);
                }
                break;
            }
        }
    }

    FVector t = {0, 0, 0};
    if (SafeReadFVector(collComp + PRIMCOMP_TRANSLATION, &t)) {
        SafeWriteVector3(collComp + PRIMCOMP_TRANSLATION,
                         forwardOffset, t.y, t.z);
    }
}

// ============ ABILITY COOLDOWNS ============
static void ApplyAbilityCooldowns() {
    if (!ValidPtr(g_PC)) return;
    if (!g_FastCooldowns) return;

    uintptr_t classCooldown = 0;
    if (!SafeRead(g_PC + PC_DEFAULT_COOLDOWN_TEMPLATE, &classCooldown)) return;
    if (!ValidPtr(classCooldown)) return;

    uintptr_t setCooldown = 0;
    if (!SafeRead(classCooldown + CLASSCOOLDOWN_PLAYER_COOLDOWN, &setCooldown)) return;
    if (!ValidPtr(setCooldown)) return;

    uintptr_t maybeData = 0;
    int32_t   maybeCount = 0;
    SafeRead(setCooldown + SETCOOLDOWN_ABILITY_COOLDOWNS, &maybeData);
    SafeRead(setCooldown + SETCOOLDOWN_ABILITY_COOLDOWNS + 0x8, &maybeCount);

    uintptr_t base = 0;
    int entryCount = 0;

    if (ValidPtr(maybeData) && maybeCount > 0 && maybeCount <= 8) {
        base = maybeData;
        entryCount = maybeCount;
    } else {
        base = setCooldown + SETCOOLDOWN_ABILITY_COOLDOWNS;
        entryCount = 1;
    }

    for (int i = 0; i < entryCount; i++) {
        uintptr_t entry = base + (i * FSGABILCD_SIZE);

        float fMin = 0.0f, fMax = 0.0f;
        if (!SafeRead(entry + FSGABILCD_MIN, &fMin)) continue;
        if (!SafeRead(entry + FSGABILCD_MAX, &fMax)) continue;
        if (fMax <= 0.0f || fMax > 1000.0f) continue;
        if (fMin < -1000.0f || fMin >= fMax) continue;

        float timeout = 0.0f;
        if (SafeRead(entry + FSGABILCD_TIMEOUT, &timeout) && timeout > 0.1f) {
            float scaled = timeout * g_CooldownMultiplier;
            if (scaled < 0.05f) scaled = 0.05f;
            SafeWriteFloat(entry + FSGABILCD_TIMEOUT, scaled);
        }
    }
}

// ============ CONSOLE COMMAND PIPELINE ============
static void SendKey(WORD vkCode, bool keyDown) {
    INPUT input = {0};
    input.type = INPUT_KEYBOARD;
    input.ki.wVk = vkCode;
    input.ki.dwFlags = keyDown ? 0 : KEYEVENTF_KEYUP;
    SendInput(1, &input, sizeof(INPUT));
}

static void ReleaseGameplayKeys() {
    const WORD keys[] = {
        'W', 'A', 'S', 'D',
        VK_SPACE, VK_SHIFT, VK_CONTROL,
        VK_UP, VK_DOWN, VK_LEFT, VK_RIGHT
    };
    for (WORD k : keys) {
        INPUT in = {0};
        in.type = INPUT_KEYBOARD;
        in.ki.wVk = k;
        in.ki.dwFlags = KEYEVENTF_KEYUP;
        SendInput(1, &in, sizeof(INPUT));
    }
}

static void TypeStringFast(const char* text) {
    for (int i = 0; text[i] != '\0'; i++) {
        char c = text[i];
        SHORT vk = VkKeyScanA(c);
        BYTE keyCode    = LOBYTE(vk);
        BYTE shiftState = HIBYTE(vk);

        if (shiftState & 1) { SendKey(VK_SHIFT, true); Sleep(1); }
        SendKey(keyCode, true);
        Sleep(1);
        SendKey(keyCode, false);
        if (shiftState & 1) { SendKey(VK_SHIFT, false); }
        Sleep(2);
    }
}

struct ConsoleCommandData {
    char command[350];
    volatile bool executing;
};
static ConsoleCommandData g_PendingCommand = { "", false };
static HANDLE g_CommandThread = NULL;
static bool g_ConsoleWasOpen = false;

static DWORD WINAPI CommandExecutionThread(LPVOID) {
    g_ConsoleBusy = true;

    ReleaseGameplayKeys();
    Sleep(30);

    bool needToggle = !g_ConsoleWasOpen;
    if (needToggle) {
        SendKey(VK_OEM_3, true);  Sleep(30);  SendKey(VK_OEM_3, false);
        Sleep(50);
    }

    TypeStringFast(g_PendingCommand.command);
    Sleep(20);

    SendKey(VK_RETURN, true); Sleep(10); SendKey(VK_RETURN, false);
    Sleep(20);

    if (needToggle) {
        SendKey(VK_OEM_3, true);  Sleep(30); SendKey(VK_OEM_3, false);
    }

    g_ConsoleBusy = false;
    g_PendingCommand.executing = false;
    return 0;
}

static void ExecuteConsoleCommand(const char* command) {
    if (g_PendingCommand.executing) return;

    strncpy_s(g_PendingCommand.command, command, _TRUNCATE);
    g_PendingCommand.executing = true;

    if (g_CommandThread) { CloseHandle(g_CommandThread); g_CommandThread = NULL; }
    g_CommandThread = CreateThread(NULL, 0, CommandExecutionThread, NULL, 0, NULL);
}

static bool IsConsoleBlockingInput() {
    if (g_ConsoleBusy) return true;
    if (g_ConsoleBlockUntil != 0 && GetTickCount() < g_ConsoleBlockUntil) return true;
    return false;
}

// ============ VOTE-KICK DODGE ============
void ResetVoteKickLatch() {
    g_DodgeFiredThisVote = false;
    g_LatchedVoteMsg     = 0;
    g_LatchedTargetId    = -1;
    g_LastVoteMsg        = 0;
    g_LastVoteTargetId   = -1;
    g_ConsoleBusy        = false;
}

void CheckVoteKickDodge() {
    if (!g_VoteKickDodge) {
        ResetVoteKickLatch();
        return;
    }
    if (!ValidPtr(g_PC)) return;

    uintptr_t voteMsg = 0;
    if (!SafeRead(g_PC + PC_ACTIVE_VOTE, &voteMsg) || !ValidPtr(voteMsg)) {
        ResetVoteKickLatch();
        return;
    }

    bool systemCalled = false;
    SafeRead(voteMsg + VOTE_M_BSYSTEMCALLED, &systemCalled);
    if (!g_DodgeOnPlayerKick && !systemCalled) return;

    int32_t targetId = 0;
    if (!SafeRead(voteMsg + VOTE_M_TARGETTOKICKID, &targetId)) return;
    if (targetId <= 0 || targetId > 0xFFFFFF) return;

    uintptr_t pri = 0;
    if (!SafeRead(g_PC + PC_M_SGPRI, &pri) || !ValidPtr(pri)) return;

    int32_t myId = 0;
    if (!SafeRead(pri + PRI_PLAYER_ID, &myId)) return;
    if (myId <= 0) return;

    g_LastVoteMsg        = voteMsg;
    g_LastVoteTargetId   = targetId;

    if (targetId != myId) return;

    bool sameVote = (voteMsg   == g_LatchedVoteMsg) &&
                    (targetId  == g_LatchedTargetId);

    if (sameVote && g_DodgeFiredThisVote) return;

    g_LatchedVoteMsg     = voteMsg;
    g_LatchedTargetId    = targetId;
    g_DodgeFiredThisVote = false;

    printf("[Dodge] Kick vote target ID=%d matches me (%d). Sending 'disconnect'.\n",
           targetId, myId);

    SafeWriteBool(g_PC + PC_DEVELOPER_CONSOLE_ENABLED, true);
    Sleep(16);

    g_ConsoleBlockUntil = GetTickCount() + VOTEKICK_TIMER_MS;
    ExecuteConsoleCommand("disconnect");

    g_DodgeFiredThisVote = true;
    g_VoteKickDodgeFired = true;
    g_DodgeFiredAtTick   = GetTickCount();
}

// ============ TP TARGETS ============
uintptr_t GetClosestEnemyInFOV(FVector myLoc, FRotator myRot) {
    if (g_AllEnemies.empty()) return 0;
    uintptr_t closest = 0;
    float closestDist = 999999.0f;
    float aimFov = g_FovCircleRadius * 0.075f;

    for (uintptr_t p : g_AllEnemies) {
        if (!ValidPtr(p)) continue;
        FVector targetLoc = {0,0,0};
        if (!SafeReadFVector(p + ACTOR_LOCATION, &targetLoc)) continue;

        float dx = targetLoc.x - myLoc.x;
        float dy = targetLoc.y - myLoc.y;
        float dz = targetLoc.z - myLoc.z;

        float yawReq = atan2f(dy, dx) * 57.2957f;
        float pitchReq = atan2f(dz, sqrtf(dx*dx + dy*dy)) * 57.2957f;
        float mY = (float)myRot.yaw / (UR_UNITS / 57.2957f);
        float mP = (float)myRot.pitch / (UR_UNITS / 57.2957f);
        float dY = fabsf(yawReq - mY); if (dY > 180.0f) dY = fabsf(360.0f - dY);
        float dP = fabsf(pitchReq - mP);

        if (dY < aimFov && dP < aimFov) {
            float d = sqrtf(dx*dx + dy*dy + dz*dz);
            if (d < closestDist) { closestDist = d; closest = p; }
        }
    }
    return closest;
}

uintptr_t GetRandomTarget() {
    if (ValidPtr(g_RandomEnemyTarget)) {
        for (uintptr_t p : g_RandomTpPool) {
            if (p == g_RandomEnemyTarget) return g_RandomEnemyTarget;
        }
        g_RandomEnemyTarget = 0;
    }

    if (g_RandomTpPool.empty()) return 0;

    g_RandomEnemyTarget = g_RandomTpPool[rand() % g_RandomTpPool.size()];
    return g_RandomEnemyTarget;
}

uintptr_t GetRandomDownedTeammate(int myTeam) {
    std::vector<uintptr_t> downed;
    ForEachPawn([&](uintptr_t p) {
        if (p == g_LocalPawn) return;
        if (IsPawnDowned(p)) {
            int t = GetPawnTeam(p);
            if (t == myTeam && t != -1) downed.push_back(p);
        }
    });
    if (downed.empty()) return 0;
    return downed[rand() % downed.size()];
}

bool GetCrosshairTraceData(uintptr_t pc, FVector& outHit, uintptr_t& outActor) {
    if (!ValidPtr(pc)) return false;
    uintptr_t tracePtr = pc + 0x1828;
    bool valid = false;
    if (!SafeRead(tracePtr + 0x0, &valid) || !valid) return false;
    SafeRead(tracePtr + 0x4, &outActor);
    SafeReadFVector(tracePtr + 0x28, &outHit);
    return true;
}

bool GetPlayerViewPoint(FVector& outLoc, FRotator& outRot) {
    if (!ValidPtr(g_PC)) return false;
    uintptr_t vtable = 0;
    if (!SafeRead(g_PC, &vtable) || !ValidPtr(vtable)) return false;
    uintptr_t func = 0;
    if (!SafeRead(vtable + 0x9E0, &func) || !ValidPtr(func)) return false;
    typedef void(__fastcall* tGetVP)(uintptr_t, FVector*, FRotator*);
    ((tGetVP)func)(g_PC, &outLoc, &outRot);
    return true;
}

// ============ CAMERA DEBUG HELPERS ============
uintptr_t ResolveSGCamera() {
    if (!ValidPtr(g_PC)) return 0;
    uintptr_t sgPawn = 0, viewTarget = 0, cam = 0;
    if (!SafeRead(g_PC + 0x17a8, &sgPawn) || !ValidPtr(sgPawn)) return 0;
    if (!SafeRead(sgPawn + 0x1df8, &viewTarget) || !ValidPtr(viewTarget)) return 0;
    if (!SafeRead(viewTarget + 0x18e4, &cam) || !ValidPtr(cam)) return 0;
    return cam;
}

// ============ ALWAYS LOOK AT GROUND ============
// We determined from the Copy All dump that the LIVE pitch is at:
//   g_PC + 0x33C (PC.Rotation.Pitch)     <-- the source of truth
//   ASGCamera + 0x6A0 (POV.Rotation.Pitch) <-- copied from PC each frame
// We write to BOTH so no matter which one the game reads first, it snaps down.
// Yaw is deliberately preserved so you can still track targets horizontally.
static void ApplyLookAtGround() {
    if (!ValidPtr(g_PC)) return;

    // Only the pitch is forced. Yaw and roll stay wherever the player aimed them.
    SafeWriteInt(g_PC + ACTOR_ROTATION + 0, g_LookGroundPitch);

    uintptr_t cam = ResolveSGCamera();
    if (ValidPtr(cam)) {
        SafeWriteInt(cam + ACAMERA_POV_ROTATION_PITCH, g_LookGroundPitch);
    }

    // Also nudge the pawn's pitch (usually 0, but for consistency)
    if (ValidPtr(g_LocalPawn)) {
        SafeWriteInt(g_LocalPawn + ACTOR_ROTATION + 0, g_LookGroundPitch);
    }

    g_LastLookGroundApply = GetTickCount();
    g_LookGroundApplyCount++;
}

static void UpdateLookAtGround() {
    if (!ValidPtr(g_PC)) return;

    // Always keep the last-seen pitch refreshed for the debug UI
    int32_t curPitch = 0;
    SafeRead(g_PC + ACTOR_ROTATION + 0, &curPitch);
    g_LastSeenPitch = curPitch;

    if (!g_LookGroundEnabled) return;

    DWORD now = GetTickCount();

    // ----- 1. Recoil-triggered instant snap -----
    // If the game pushed the pitch UP (i.e., it's higher than our trigger, which is
    // closer to zero / positive), snap back immediately. This is what kills recoil
    // in real time.
    if (g_LookGroundRecoilSnap && curPitch > g_LookGroundRecoilTrig) {
        ApplyLookAtGround();
        return;
    }

    // ----- 2. Timed re-apply -----
    if ((now - g_LastLookGroundApply) >= (DWORD)(g_LookGroundInterval * 1000.0f)) {
        ApplyLookAtGround();
    }
}

// ============ GAME LOGIC ============
void RunGameLogic() {
    if (!g_Base) return;

    uintptr_t root = 0;
    if (!SafeRead(g_Base + EXCEPTION_INFO_PTR, &root)) return;
    if (!ValidPtr(root)) return;

    uintptr_t lpArray = 0;
    if (!SafeRead(root + 0x750, &lpArray) || !ValidPtr(lpArray)) return;

    uintptr_t lp = 0;
    if (!SafeRead(lpArray, &lp)) return;

    uintptr_t newPC = 0;
    if (!SafeRead(lp + 0x68, &newPC) || !ValidPtr(newPC)) {
        if (g_PC != 0) ResetVoteKickLatch();
        g_PC = 0; g_LocalPawn = 0;
        g_PawnCache.clear();
        g_AllEnemies.clear();
        g_RandomTpPool.clear();
        g_StepActive = false;
        return;
    }

    if (newPC != g_PC) ResetVoteKickLatch();
    g_PC = newPC;

    uintptr_t localPawn = 0;
    if (!SafeRead(g_PC + ASGPLAYERCONTROLLER_SGPAWN, &localPawn) || !ValidPtr(localPawn))
        return;
    g_LocalPawn = localPawn;

    static bool s_HadFocus = true;
    bool hasFocus = hWindow && (GetForegroundWindow() == hWindow);
    if (hasFocus && !s_HadFocus) {
        g_TpWasKeyDown = false;
        g_TpActive     = false;
        g_StepActive   = false;
    }
    s_HadFocus = hasFocus;

    // ==================== ALWAYS LOOK AT GROUND ====================
    // Runs early so the write goes in before anything reads the rotation.
    UpdateLookAtGround();

    UpdateSteppedTP();

    int myTeam = GetPawnTeam(localPawn);

    BuildEnemyLists();

    if (g_NoRecoil) {
        SafeWriteFloat(localPawn + 0x1ACC, 0.0f);
        SafeWriteFloat(localPawn + 0x1AD0, 0.0f);
        SafeWriteFloat(localPawn + 0x1AD4, 0.0f);
    }

    if (g_FastCooldowns) ApplyAbilityCooldowns();

    uintptr_t weapon = 0;
    if (!SafeRead(localPawn + APAWN_WEAPON, &weapon) || !ValidPtr(weapon))
        return;

    if (g_NoRecoil) SafeWriteFloat(weapon + WEAPON_SPREADRECOVERYTIME, 0.0f);
    if (g_NoSpread) {
        SafeWriteFloat(weapon + 0x13dc, g_CustomSpreadValue);
        SafeWriteFloat(weapon + 0x13e0, g_CustomSpreadValue);
    }

    bool isMelee = false;
    SafeRead(weapon + AWEAPON_BMELEEWEAPON, &isMelee);

    if (g_FastMelee && isMelee) {
        SafeWriteFloat(weapon + WEAPON_FIREINTERVALMODIFIED, g_MeleeFireInterval);
        SafeWriteFloat(weapon + WEAPON_FIREINTERVALAUGMENTMOD, 0.0f);

        uintptr_t fiData = 0;
        int32_t fiCount = 0;
        if (SafeRead(weapon + AWEAPON_FIREINTERVAL, &fiData) && ValidPtr(fiData)) {
            if (SafeRead(weapon + AWEAPON_FIREINTERVAL_COUNT_OFF, &fiCount)) {
                int maxWrite = (fiCount > 0 && fiCount < 8) ? fiCount : 2;
                for (int i = 0; i < maxWrite; i++) {
                    SafeWriteFloat(fiData + (i * 4), g_MeleeFireInterval);
                }
            }
        }

        if (g_FastMeleeForceNextFire && g_MeleeFireInterval < 0.5f) {
            SafeWriteFloat(weapon + WEAPON_NEXTFIRETIME, 0.0f);
        }
    }

    if (g_MeleeRange && isMelee) {
        uintptr_t proxy = 0;
        bool proxyOk = false;
        if (SafeRead(weapon + SGMELEE_M_CURRENTACTIVEPROXY, &proxy) && ValidPtr(proxy)) {
            proxyOk = true;
        } else if (SafeRead(weapon + SGMELEE_M_IMPACTPROXY, &proxy) && ValidPtr(proxy)) {
            proxyOk = true;
        }

        if (proxyOk) {
            uintptr_t collComp = 0;
            if (SafeRead(proxy + IMPACTPROXY_MELECOLLISIONCOMP, &collComp) && ValidPtr(collComp)) {
                SafeWriteFloat(collComp + PRIMCOMP_BOUNDSSCALE, g_MeleeBoundsScale);
                if (g_MeleeVisualScale) {
                    float s = g_MeleeBoundsScale;
                    SafeWriteFloat(collComp + PRIMCOMP_SCALE, s);
                    SafeWriteVector3(collComp + PRIMCOMP_SCALE3D, s, s, s);
                }
                if (g_MeleeWideAngle)
                    SafeWriteFloat(weapon + SGMELEE_M_MAXIMPACTPROXYHITDOT, g_MeleeHitDot);

                if (g_MeleePushForward && g_MeleeForwardOffset != 0.0f) {
                    ApplyMeleeForwardOffset(proxy, collComp, g_MeleeForwardOffset);
                }
            }
        }
    }

    BuildViewProj();

    FVector myLoc = {0,0,0};
    FRotator myRot = {0,0,0};
    GetPlayerViewPoint(myLoc, myRot);

    g_PawnCache.clear();
    g_PawnCache.reserve(64);

    ForEachPawn([&](uintptr_t pawn) {
        if (pawn == g_LocalPawn) return;
        if (!IsPawnAlive(pawn)) return;

        int hp = 0; SafeRead(pawn + 0x81C, &hp);
        int hpMax = 0; SafeRead(pawn + 0x820, &hpMax);
        int team = GetPawnTeam(pawn);
        bool isEnemy = (team != myTeam || team == -1);

        FVector loc;
        if (!SafeReadFVector(pawn + ACTOR_LOCATION, &loc)) return;

        int fullHeight = 0; SafeRead(pawn + 0x73C, &fullHeight);
        float halfH = (fullHeight > 0 && fullHeight < 200) ? (float)fullHeight / 2.0f : 44.0f;

        FVector feetPos = { loc.x, loc.y, loc.z - halfH };
        FVector headPos = { loc.x, loc.y, loc.z + halfH };

        Vector2 cScreen, fScreen, hScreen;
        if (!WorldToScreen(loc, cScreen)) return;
        if (!WorldToScreen(feetPos, fScreen)) return;
        if (!WorldToScreen(headPos, hScreen)) return;

        CachedPawn cp;
        cp.screenCenter = ImVec2(cScreen.x, cScreen.y);
        cp.sBase = ImVec2(fScreen.x, fScreen.y);
        cp.sHead = ImVec2(hScreen.x, hScreen.y);
        float boxHeight = fabsf(cp.sBase.y - cp.sHead.y);
        float boxWidth = boxHeight * 0.5f;
        cp.boxMin = ImVec2(cp.screenCenter.x - boxWidth / 2.0f, cp.sHead.y);
        cp.boxMax = ImVec2(cp.screenCenter.x + boxWidth / 2.0f, cp.sBase.y);
        cp.hp = hp;
        cp.hpMax = hpMax;
        cp.team = team;
        cp.isEnemy = isEnemy;
        cp.isDowned = IsPawnDowned(pawn);
        cp.pawnPtr = pawn;
        strcpy_s(cp.name, "Player");

        bool found = false;
        for (auto& nc : g_PawnNames)
            if (nc.pawnPtr == pawn) { strcpy_s(cp.name, nc.name); found = true; break; }
        if (!found) {
            uintptr_t pri = 0;
            if (SafeRead(pawn + 0x3F0, &pri) && ValidPtr(pri)) {
                char tmp[64];
                ReadFString(pri + 0x538, tmp, 64);
                if (tmp[0]) {
                    strcpy_s(cp.name, tmp);
                    PawnNameCache nc;
                    nc.pawnPtr = pawn;
                    strcpy_s(nc.name, tmp);
                    g_PawnNames.push_back(nc);
                }
            }
        }

        g_PawnCache.push_back(cp);
    });

    if (g_PawnNames.size() > 100) {
        g_PawnNames.erase(g_PawnNames.begin(), g_PawnNames.begin() + (g_PawnNames.size() - 50));
    }

    CheckVoteKickDodge();

    bool inputBlocked = IsConsoleBlockingInput();

    // ==================== AUTO SHOOT ====================
    if (!inputBlocked && g_AutoShootEnabled && ValidPtr(g_PC)) {
        static bool s_ToggleState = false;
        static bool s_KeyWasDown  = false;

        bool keyDown     = (GetAsyncKeyState(g_AutoShootKey) & 0x8000) != 0;
        bool justPressed = keyDown && !s_KeyWasDown;
        s_KeyWasDown = keyDown;

        bool active;
        if (g_AutoShootToggleMode) {
            if (justPressed) s_ToggleState = !s_ToggleState;
            active = s_ToggleState;
        } else {
            active = keyDown;
        }

        if (active) {
            bool shouldShoot = true;

            if (g_AutoShootTeamCheck) {
                uintptr_t tracePtr = g_PC + 0x1828;
                bool traceValid = false;
                SafeRead(tracePtr + 0x0, &traceValid);

                if (traceValid) {
                    uintptr_t hitActor = 0;
                    SafeRead(tracePtr + 0x4, &hitActor);

                    if (ValidPtr(hitActor)) {
                        int hitTeam = GetPawnTeam(hitActor);
                        if (hitTeam == myTeam && hitTeam != -1) {
                            shouldShoot = false;
                        }
                    }
                }
            }

            if (shouldShoot) {
                DWORD now = GetTickCount();
                if ((now - g_LastAutoShootShot) >= (DWORD)g_AutoShootDelay) {
                    INPUT in = {0};
                    in.type = INPUT_MOUSE;
                    in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
                    SendInput(1, &in, sizeof(INPUT));
                    in.mi.dwFlags = MOUSEEVENTF_LEFTUP;
                    SendInput(1, &in, sizeof(INPUT));
                    g_LastAutoShootShot = now;
                }
            }
        }
    }

    if (!inputBlocked && g_TpEnabled && g_TpMode == 0) {
        g_CurrentTpTarget = GetClosestEnemyInFOV(myLoc, myRot);
    } else {
        g_CurrentTpTarget = 0;
    }

    DWORD now = GetTickCount();
    if (!inputBlocked && g_TpActive && (now - g_LastLocationCheck) >= 50) {
        g_LastLocationCheck = now;
        bool isMoving =
            (GetAsyncKeyState('W') & 0x8000) ||
            (GetAsyncKeyState('A') & 0x8000) ||
            (GetAsyncKeyState('S') & 0x8000) ||
            (GetAsyncKeyState('D') & 0x8000);
        if (isMoving) {
            g_TpActive = false;
        } else if (!g_StepActive) {
            uintptr_t follow = 0;
            if (g_TpMode == 0) follow = g_CurrentTpTarget;
            else if (g_TpMode == 1) follow = g_RandomEnemyTarget;
            if (ValidPtr(follow)) {
                FVector tloc;
                if (SafeReadFVector(follow + ACTOR_LOCATION, &tloc)) {
                    PerformTP(localPawn, tloc);
                }
            }
        }
    }

    bool isTpKeyDown = !inputBlocked && ((GetAsyncKeyState(g_TpKey) & 0x8000) != 0);
    bool justTpPressed = isTpKeyDown && !g_TpWasKeyDown;
    g_TpWasKeyDown = isTpKeyDown;

    if (!inputBlocked && g_TpEnabled && justTpPressed) {
        if ((now - g_LastTpTime) > (DWORD)(g_TpCooldown * 1000.0f)) {
            uintptr_t target = 0;
            FVector tloc;
            bool didTp = false;

            switch (g_TpMode) {
                case 0:
                    target = GetClosestEnemyInFOV(myLoc, myRot);
                    if (ValidPtr(target) && SafeReadFVector(target + ACTOR_LOCATION, &tloc)) {
                        PerformTP(localPawn, tloc);
                        g_CurrentTpTarget = target;
                        g_TpActive = true;
                        g_LastLocationCheck = now;
                        didTp = true;
                    }
                    break;
                case 1:
                    target = GetRandomTarget();
                    if (ValidPtr(target) && SafeReadFVector(target + ACTOR_LOCATION, &tloc)) {
                        PerformTP(localPawn, tloc);
                        g_TpActive = true;
                        g_LastLocationCheck = now;
                        didTp = true;
                    } else {
                        g_TpActive = false;
                    }
                    break;
                case 2:
                    target = GetRandomDownedTeammate(myTeam);
                    if (ValidPtr(target) && SafeReadFVector(target + ACTOR_LOCATION, &tloc)) {
                        PerformTP(localPawn, tloc);
                        didTp = true;
                    }
                    g_TpActive = false;
                    break;
                case 3: {
                    FVector hit = {0,0,0};
                    uintptr_t hitActor = 0;
                    if (GetCrosshairTraceData(g_PC, hit, hitActor)) {
                        PerformTP(localPawn, hit);
                        didTp = true;
                    }
                    g_TpActive = false;
                    break;
                }
            }

            if (didTp) g_LastTpTime = now;
        }
    }
}

// ============ ESP DRAW ============
void DrawESP() {
    if (!g_pDevice || !g_EspEnabled) return;

    D3DVIEWPORT9 vp = {};
    if (SUCCEEDED(g_pDevice->GetViewport(&vp))) {
        if (g_FovCircleEnabled)
            ImGui::GetForegroundDrawList()->AddCircle(
                ImVec2((float)vp.Width / 2, (float)vp.Height / 2),
                g_FovCircleRadius, IM_COL32_WHITE, 100, 2);
    }

    if (g_PawnCache.empty()) return;
    auto dl = ImGui::GetForegroundDrawList();
    int maxDraw = (g_PawnCache.size() < 100) ? (int)g_PawnCache.size() : 100;

    for (int i = 0; i < maxDraw; i++) {
        const auto& cp = g_PawnCache[i];

        if (!cp.isEnemy && !g_EspTeammates) continue;
        if (!cp.isEnemy && cp.isDowned && !g_EspDownedTeammates) continue;

        ImU32 col;
        if (cp.isDowned && !cp.isEnemy)
            col = IM_COL32(255, 165, 0, 255);
        else if (g_TpEnabled && g_TpMode == 0 && cp.pawnPtr == g_CurrentTpTarget && cp.isEnemy)
            col = IM_COL32(144, 238, 144, 255);
        else if (!cp.isEnemy)
            col = IM_COL32(0, 150, 255, 255);
        else
            col = IM_COL32(255, 0, 0, 255);

        if (g_EspBox)
            dl->AddRect(cp.boxMin, cp.boxMax, col);

        if (g_EspTracers) {
            ImVec2 sc((float)vp.Width / 2.0f, (float)vp.Height);
            dl->AddLine(sc, cp.screenCenter, col, 1.5f);
        }

        if (g_EspHealth) {
            float h = fabsf(cp.boxMax.y - cp.boxMin.y);
            float pct = (cp.hpMax > 0) ? (float)cp.hp / (float)cp.hpMax : 0.0f;
            if (pct > 1.0f) pct = 1.0f;
            ImU32 hpc = IM_COL32(0, 255, 0, 255);
            if (pct < 0.3f) hpc = IM_COL32(255, 0, 0, 255);
            else if (pct < 0.6f) hpc = IM_COL32(255, 255, 0, 255);

            dl->AddRectFilled(ImVec2(cp.boxMin.x - 6, cp.boxMin.y),
                              ImVec2(cp.boxMin.x - 2, cp.boxMax.y),
                              IM_COL32(0, 0, 0, 150));
            dl->AddRectFilled(ImVec2(cp.boxMin.x - 5, cp.boxMax.y - (h * pct)),
                              ImVec2(cp.boxMin.x - 3, cp.boxMax.y),
                              hpc);
        }

        if (g_EspNames && cp.name[0] != '\0') {
            ImVec2 ts = ImGui::CalcTextSize(cp.name);
            ImVec2 p((cp.boxMin.x + cp.boxMax.x) / 2.0f - ts.x / 2.0f, cp.boxMin.y - 18.0f);
            dl->AddText(ImVec2(p.x + 1, p.y + 1), IM_COL32(0, 0, 0, 200), cp.name);
            dl->AddText(p, col, cp.name);
        }
    }
}

// ============ WNDPROC ============
extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    if (uMsg == WM_KEYDOWN && wParam == VK_INSERT) {
        bShowMenu = !bShowMenu;
        if (bShowMenu) { ClipCursor(NULL); ShowCursor(TRUE); }
        return 0;
    }

    bool blockKeyboard = g_ConsoleBusy ||
                         (g_ConsoleBlockUntil != 0 && GetTickCount() < g_ConsoleBlockUntil);

    if (blockKeyboard) {
        switch (uMsg) {
            case WM_KEYDOWN:
            case WM_KEYUP:
            case WM_SYSKEYDOWN:
            case WM_SYSKEYUP:
            case WM_CHAR:
            case WM_DEADCHAR:
            case WM_SYSCHAR:
                if (wParam == VK_OEM_3) break;
                return 0;
        }
    }

    if (bShowMenu) {
        ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam);
        switch (uMsg) {
            case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_LBUTTONDBLCLK:
            case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_RBUTTONDBLCLK:
            case WM_MBUTTONDOWN: case WM_MBUTTONUP: case WM_MBUTTONDBLCLK:
            case WM_MOUSEMOVE: case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
            case WM_INPUT: return 1;
            default: break;
        }
    }
    return CallWindowProc(oWndProc, hWnd, uMsg, wParam, lParam);
}

// ============ KEYBIND HELPERS ============
struct KeyBindOpt { const char* name; int code; };
static KeyBindOpt g_Keys[] = {
    { "Left Click",  VK_LBUTTON },
    { "Right Click", VK_RBUTTON },
    { "Middle Click",VK_MBUTTON },
    { "Mouse 4",     VK_XBUTTON1 },
    { "Mouse 5",     VK_XBUTTON2 },
    { "Shift",       VK_SHIFT },
    { "V",           'V' },
    { "Caps Lock",   VK_CAPITAL },
    { "F1",          VK_F1 },
    { "F2",          VK_F2 },
    { "F3",          VK_F3 },
    { "F4",          VK_F4 },
    { "E",           'E' },
    { "Q",           'Q' },
    { "T",           'T' },
};
static const int g_KeysCount = sizeof(g_Keys) / sizeof(g_Keys[0]);

static KeyBindOpt g_AutoShootKeys[] = {
    { "Mouse 4",     VK_XBUTTON1 },
    { "Mouse 5",     VK_XBUTTON2 },
    { "Left Alt",    VK_LMENU },
    { "Right Alt",   VK_RMENU },
    { "V",           'V' },
    { "Caps Lock",   VK_CAPITAL },
    { "F",           'F' },
    { "G",           'G' },
};
static const int g_AutoShootKeysCount = sizeof(g_AutoShootKeys) / sizeof(g_AutoShootKeys[0]);

static int KeyIndexFor(int code) {
    for (int i = 0; i < g_KeysCount; i++)
        if (g_Keys[i].code == code) return i;
    return 0;
}

static const char* KeyGetter(void* data, int idx) {
    return ((KeyBindOpt*)data)[idx].name;
}

// ============ GUI ============
void DrawGUI() {
    ImGui::NewFrame();
    ImGuiIO& io = ImGui::GetIO();
    io.MouseDrawCursor = bShowMenu;

    if (bShowMenu) {
        if (hWindow) {
            POINT p;
            if (GetCursorPos(&p) && ScreenToClient(hWindow, &p))
                io.MousePos = ImVec2((float)p.x, (float)p.y);
            io.MouseDown[0] = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
            io.MouseDown[1] = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
        }

        ImGui::SetNextWindowSize(ImVec2(560, 780), ImGuiCond_FirstUseEver);
        ImGui::Begin("Dirty Bomb Mod Menu v9.13", &bShowMenu, ImGuiWindowFlags_NoCollapse);

        if (ImGui::BeginTabBar("Tabs")) {
            // ---- WEAPON ----
            if (ImGui::BeginTabItem("Weapon")) {
                if (ImGui::CollapsingHeader("Weapon Features", ImGuiTreeNodeFlags_DefaultOpen)) {
                    ImGui::Checkbox("No Recoil", &g_NoRecoil);
                    ImGui::Checkbox("No Spread", &g_NoSpread);
                    if (g_NoSpread) {
                        ImGui::Indent();
                        ImGui::SliderFloat("Spread Value", &g_CustomSpreadValue, 0.0f, 2.0f, "%.3f");
                        ImGui::Unindent();
                    }
                }

                if (ImGui::CollapsingHeader("Melee", ImGuiTreeNodeFlags_DefaultOpen)) {
                    ImGui::Checkbox("Melee Range", &g_MeleeRange);
                    if (g_MeleeRange) {
                        ImGui::Indent();
                        ImGui::SliderFloat("Bounds Scale", &g_MeleeBoundsScale, 1.0f, 5.0f, "%.2fx");
                        ImGui::Checkbox("Wide Hit Angle", &g_MeleeWideAngle);
                        if (g_MeleeWideAngle) {
                            ImGui::Indent();
                            ImGui::SliderFloat("Hit Dot", &g_MeleeHitDot, -1.0f, 1.0f, "%.2f");
                            ImGui::Unindent();
                        }
                        ImGui::Checkbox("Visual Scale (debug)", &g_MeleeVisualScale);

                        ImGui::Separator();
                        ImGui::Checkbox("Push Capsule Forward", &g_MeleePushForward);
                        if (g_MeleePushForward) {
                            ImGui::Indent();
                            ImGui::SliderFloat("Forward Offset", &g_MeleeForwardOffset,
                                               0.0f, 10.0f, "%.2f");
                            ImGui::TextDisabled("2.3 is the sweet spot vs players");
                            ImGui::Unindent();
                        }
                        ImGui::Unindent();
                    }

                    ImGui::Separator();
                    ImGui::Checkbox("Fast / Slow Melee (LMB + RMB)", &g_FastMelee);
                    if (g_FastMelee) {
                        ImGui::Indent();
                        ImGui::SliderFloat("Fire Interval (s)", &g_MeleeFireInterval,
                                           0.01f, 5.0f, "%.3f s",
                                           ImGuiSliderFlags_Logarithmic);
                        float rate = (g_MeleeFireInterval > 0.0001f)
                                     ? (1.0f / g_MeleeFireInterval) : 0.0f;
                        ImGui::TextDisabled("Rate: %.2f swings / second", rate);

                        if (ImGui::SmallButton("Slow (2s)"))      g_MeleeFireInterval = 2.0f;
                        ImGui::SameLine();
                        if (ImGui::SmallButton("Normal (0.5s)"))  g_MeleeFireInterval = 0.5f;
                        ImGui::SameLine();
                        if (ImGui::SmallButton("Fast (0.1s)"))    g_MeleeFireInterval = 0.1f;
                        ImGui::SameLine();
                        if (ImGui::SmallButton("Insane (0.01s)")) g_MeleeFireInterval = 0.01f;

                        ImGui::Checkbox("Force Next Fire = Now", &g_FastMeleeForceNextFire);
                        ImGui::Unindent();
                    }
                }

                if (ImGui::CollapsingHeader("Auto Shoot", ImGuiTreeNodeFlags_DefaultOpen)) {
                    ImGui::Checkbox("Enable Auto Shoot", &g_AutoShootEnabled);
                    if (g_AutoShootEnabled) {
                        ImGui::Indent();

                        ImGui::Checkbox("Toggle Mode (press once to fire)", &g_AutoShootToggleMode);
                        if (g_AutoShootToggleMode)
                            ImGui::TextColored(ImVec4(0,1,0,1),
                                "  Press key = fire, press again = stop.");
                        else
                            ImGui::TextColored(ImVec4(0,1,0,1),
                                "  Hold key = fire.");

                        ImGui::Checkbox("Team Check##AutoShoot", &g_AutoShootTeamCheck);
                        ImGui::TextDisabled("Don't fire when crosshair is on a teammate");

                        ImGui::SliderInt("Fire Delay (ms)##AutoShoot", &g_AutoShootDelay, 0, 500);
                        if (g_AutoShootDelay == 0)       ImGui::TextDisabled("Instant");
                        else if (g_AutoShootDelay < 50)  ImGui::TextDisabled("Very fast");
                        else if (g_AutoShootDelay < 150) ImGui::TextDisabled("Fast");
                        else                             ImGui::TextDisabled("Human-like");

                        int curIdx = 0;
                        for (int i = 0; i < g_AutoShootKeysCount; i++)
                            if (g_AutoShootKeys[i].code == g_AutoShootKey) { curIdx = i; break; }

                        if (ImGui::Combo("Activation Key##AutoShoot", &curIdx,
                                         KeyGetter, (void*)g_AutoShootKeys,
                                         g_AutoShootKeysCount))
                        {
                            g_AutoShootKey = g_AutoShootKeys[curIdx].code;
                        }

                        if (g_AutoShootKey == g_TpKey)
                            ImGui::TextColored(ImVec4(1,1,0,1), "Warning: same key as TP");
                        ImGui::Unindent();
                    }
                }

                ImGui::EndTabItem();
            }

            // ---- ABILITIES ----
            if (ImGui::BeginTabItem("Abilities")) {
                ImGui::TextColored(ImVec4(1,1,0,1), "Ability Cooldowns");
                ImGui::Separator();
                ImGui::Checkbox("Faster Cooldowns", &g_FastCooldowns);
                if (g_FastCooldowns) {
                    ImGui::Indent();
                    ImGui::SliderFloat("Multiplier", &g_CooldownMultiplier, 0.05f, 1.0f, "%.2fx");
                    ImGui::Unindent();
                }
                ImGui::EndTabItem();
            }

            // ---- TELEPORT ----
            if (ImGui::BeginTabItem("Teleport Exploit")) {
                ImGui::Checkbox("Enable TP", &g_TpEnabled);
                ImGui::Separator();

                ImGui::TextColored(ImVec4(1,1,0,1), "TP Mode");
                const char* tpModes[] = {
                    "Enemy TP (FOV Circle)",
                    "Random Enemy",
                    "Random Downed Teammate",
                    "Crosshair TP"
                };
                ImGui::Combo("##TpMode", &g_TpMode, tpModes, 4);

                if (g_TpMode == 1) {
                    ImGui::Indent();
                    ImGui::Checkbox("Include Teammates (random TP)", &g_TpIncludeTeammates);
                    ImGui::TextDisabled("Off = enemies only. On = any alive player.");
                    ImGui::Unindent();
                }

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.5f,1,1,1), "AIO TP Behaviour");

                ImGui::Checkbox("Stepped TP (server-safe)", &g_TpStepped);
                ImGui::TextWrapped(g_TpStepped
                    ? "Moves in small increments so the server accepts each step. "
                      "Slower but reliable for melee."
                    : "Instant snap. Fast but may get corrected back by the server.");

                if (g_TpStepped) {
                    ImGui::Indent();
                    ImGui::SliderInt("Steps", &g_TpStepCount, 2, 15);
                    ImGui::SliderInt("Delay (ms)", &g_TpStepDelayMs, 20, 200);
                    ImGui::SliderFloat("Max units/step", &g_TpMaxStepUnits, 100.0f, 800.0f, "%.0f");
                    ImGui::TextDisabled("Lower values = safer but slower");
                    ImGui::Unindent();
                }

                ImGui::Separator();
                ImGui::Checkbox("Face Target After TP", &g_TpFaceTarget);
                ImGui::TextDisabled("Rotates controller so melee angle-check passes");
                if (g_TpFaceTarget) {
                    ImGui::Indent();
                    ImGui::SliderFloat("Aim Height Offset", &g_TpAimHeightOffset,
                                       -30.0f, 100.0f, "%.0f uu");
                    ImGui::TextDisabled("0 = feet, 40 = chest, 80 = head");
                    ImGui::Unindent();
                }

                ImGui::Separator();
                ImGui::TextColored(ImVec4(1,1,0,1), "TP Settings");
                ImGui::SliderFloat("TP Cooldown (sec)", &g_TpCooldown, 0.1f, 5.0f);

                int tpK = KeyIndexFor(g_TpKey);
                if (ImGui::Combo("TP Key", &tpK, KeyGetter, g_Keys, g_KeysCount))
                    g_TpKey = g_Keys[tpK].code;

                ImGui::Separator();
                ImGui::Checkbox("Show FOV Circle", &g_FovCircleEnabled);
                ImGui::SliderFloat("FOV Radius", &g_FovCircleRadius, 10.0f, 800.0f);

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.5f,1,1,1), "Debug Info");
                ImGui::Text("Stepping: %s (%d left)",
                            g_StepActive ? "YES" : "no", g_StepsRemaining);
                ImGui::Text("TP Active: %s", g_TpActive ? "YES" : "no");
                ImGui::Text("TP Target: 0x%llX", (unsigned long long)g_CurrentTpTarget);
                ImGui::Text("Enemies (all): %zu", g_AllEnemies.size());
                ImGui::Text("Random TP pool: %zu", g_RandomTpPool.size());

                ImGui::EndTabItem();
            }

            // ---- ESP ----
            if (ImGui::BeginTabItem("ESP")) {
                ImGui::Checkbox("Master ESP", &g_EspEnabled);
                ImGui::Separator();
                ImGui::Checkbox("ESP Box", &g_EspBox);
                ImGui::Checkbox("ESP Health Bar", &g_EspHealth);
                ImGui::Checkbox("ESP Names", &g_EspNames);
                ImGui::Checkbox("ESP Tracers", &g_EspTracers);
                ImGui::Checkbox("Show Teammates", &g_EspTeammates);
                ImGui::Checkbox("Show Downed Teammates", &g_EspDownedTeammates);
                ImGui::Checkbox("Team Check (TP FOV)", &g_TeamCheck);

                ImGui::Separator();
                ImGui::TextColored(ImVec4(1,0,0,1), "  Red    = Enemy");
                ImGui::TextColored(ImVec4(0,0.6f,1,1), "  Blue   = Teammate");
                ImGui::TextColored(ImVec4(0.56f,0.93f,0.56f,1), "  LightGreen = TP Target");
                ImGui::TextColored(ImVec4(1,0.65f,0,1), "  Orange = Downed Teammate");

                ImGui::EndTabItem();
            }

            // ---- AUTO TAB ----
            if (ImGui::BeginTabItem("Auto")) {
                ImGui::TextColored(ImVec4(1,1,0,1), "Auto Vote-Kick Dodge");
                ImGui::Separator();
                ImGui::Checkbox("Enable Vote-Kick Dodge", &g_VoteKickDodge);
                ImGui::TextWrapped("Instantly types 'disconnect' into the game console the moment "
                                   "a vote-kick targeting you is detected.");

                ImGui::Checkbox("Also dodge player-called kicks", &g_DodgeOnPlayerKick);
                ImGui::TextDisabled("Off = only dodge system/auto kicks (idle, ping, etc.)");

                ImGui::Separator();
                ImGui::Checkbox("Show 30s Rejoin Timer", &g_ShowRejoinTimer);

                if (g_ShowRejoinTimer) {
                    if (g_DodgeFiredAtTick == 0) {
                        ImGui::TextColored(ImVec4(0.5f,0.5f,0.5f,1),
                            "Rejoin timer idle (no dodge fired yet)");
                    } else {
                        DWORD elapsed = GetTickCount() - g_DodgeFiredAtTick;
                        if (elapsed < VOTEKICK_TIMER_MS) {
                            DWORD remainingMs = VOTEKICK_TIMER_MS - elapsed;
                            float remainingSec = remainingMs / 1000.0f;

                            ImGui::TextColored(ImVec4(1,0,0,1),
                                "Vote kick call still running");
                            ImGui::TextColored(ImVec4(1,0.5f,0,1),
                                "You can rejoin in %.1f s", remainingSec);

                            float prog = 1.0f - (remainingMs / (float)VOTEKICK_TIMER_MS);
                            if (prog < 0.0f) prog = 0.0f;
                            if (prog > 1.0f) prog = 1.0f;
                            ImGui::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(1,0,0,1));
                            ImGui::ProgressBar(prog, ImVec2(-1, 18));
                            ImGui::PopStyleColor();
                        } else {
                            ImGui::TextColored(ImVec4(0,1,0,1),
                                "You can now join again — vote kick timer is done");
                            ImGui::TextColored(ImVec4(0.5f,1,0.5f,1),
                                "Cleared %.0f s ago", (elapsed - VOTEKICK_TIMER_MS) / 1000.0f);
                            ImGui::ProgressBar(1.0f, ImVec2(-1, 18));
                        }
                    }
                }

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.5f,1,1,1), "Status");
                if (g_VoteKickDodgeFired)
                    ImGui::TextColored(ImVec4(1,0,0,1), "  FIRED — disconnecting");
                else if (g_LastVoteMsg)
                    ImGui::TextColored(ImVec4(1,1,0,1), "  Vote active (not targeting you)");
                else
                    ImGui::TextColored(ImVec4(0,1,0,1), "  Idle — waiting for a kick vote");

                ImGui::Text("Active vote obj: 0x%llX",
                            (unsigned long long)g_LastVoteMsg);
                ImGui::Text("Latch: msg=0x%llX target=%d fired=%s",
                            (unsigned long long)g_LatchedVoteMsg,
                            g_LatchedTargetId,
                            g_DodgeFiredThisVote ? "yes" : "no");

                bool kbBlocked = IsConsoleBlockingInput();
                if (kbBlocked) {
                    DWORD remain = (g_ConsoleBlockUntil > GetTickCount())
                                   ? (g_ConsoleBlockUntil - GetTickCount()) : 0;
                    ImGui::TextColored(ImVec4(1,0.5f,0,1),
                        "Keyboard blocked (%.1f s left)", remain / 1000.0f);
                } else {
                    ImGui::TextColored(ImVec4(0.5f,1,0.5f,1), "Keyboard free");
                }

                ImGui::EndTabItem();
            }

            // ---- LOOK AT GROUND ----
            if (ImGui::BeginTabItem("Look Ground")) {
                ImGui::TextColored(ImVec4(1,1,0,1), "Always Look at Ground");
                ImGui::TextWrapped("Force the camera pitch down to your feet so recoil "
                                   "never lifts your view. Yaw is untouched, so you can "
                                   "still sweep horizontally while shooting.");
                ImGui::Separator();

                ImGui::Checkbox("Enable##LookGround", &g_LookGroundEnabled);

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.5f,1,1,1), "Recoil Snap");

                ImGui::Checkbox("Instant snap when recoil kicks", &g_LookGroundRecoilSnap);
                ImGui::TextDisabled("Snaps back the moment the pitch rises above the trigger.");

                float trigDeg = g_LookGroundRecoilTrig * UU_TO_DEG;
                if (ImGui::SliderInt("Recoil trigger pitch",
                                     &g_LookGroundRecoilTrig,
                                     -16384, 16384))
                {
                    // no-op, slider already wrote
                }
                ImGui::TextDisabled("  (%.2f deg)  — higher = less sensitive", trigDeg);
                if (ImGui::SmallButton("Set trigger = captured + 5 deg")) {
                    g_LookGroundRecoilTrig = g_LookGroundPitch + (int32_t)(5.0f / UU_TO_DEG);
                }
                ImGui::SameLine();
                if (ImGui::SmallButton("Set trigger = captured + 1 deg")) {
                    g_LookGroundRecoilTrig = g_LookGroundPitch + (int32_t)(1.0f / UU_TO_DEG);
                }

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.5f,1,1,1), "Timed Re-apply");

                ImGui::SliderFloat("Re-apply every (sec)",
                                   &g_LookGroundInterval, 0.1f, 5.0f, "%.2f s");

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.5f,1,1,1), "Pitch Target");

                ImGui::Text("Captured pitch: %d (%.2f deg)",
                            g_LookGroundPitch, g_LookGroundPitch * UU_TO_DEG);
                if (g_LookGroundCaptured)
                    ImGui::TextColored(ImVec4(0,1,0,1), "  Pitch captured.");
                else
                    ImGui::TextColored(ImVec4(1,0.5f,0,1),
                        "  Look down, then press Copy All in Camera Debug.");

                int32_t manualPitch = g_LookGroundPitch;
                if (ImGui::SliderInt("Manual pitch override", &manualPitch,
                                     -16384, 0, "%d UU"))
                {
                    g_LookGroundPitch = manualPitch;
                    g_LookGroundCaptured = true;
                }
                ImGui::TextDisabled("  (%.2f deg)", g_LookGroundPitch * UU_TO_DEG);

                if (ImGui::SmallButton("Snap to -90 deg")) {
                    g_LookGroundPitch = -16384;
                    g_LookGroundCaptured = true;
                }
                ImGui::SameLine();
                if (ImGui::SmallButton("Snap to -80 deg")) {
                    g_LookGroundPitch = (int32_t)(-80.0f / UU_TO_DEG);
                    g_LookGroundCaptured = true;
                }
                ImGui::SameLine();
                if (ImGui::SmallButton("Snap to -60 deg")) {
                    g_LookGroundPitch = (int32_t)(-60.0f / UU_TO_DEG);
                    g_LookGroundCaptured = true;
                }

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.5f,1,1,1), "Live Status");
                ImGui::Text("Current pitch: %d (%.2f deg)",
                            g_LastSeenPitch, g_LastSeenPitch * UU_TO_DEG);
                if (g_LookGroundEnabled && ValidPtr(g_PC)) {
                    if (g_LastSeenPitch <= g_LookGroundRecoilTrig)
                        ImGui::TextColored(ImVec4(0,1,0,1), "  At or below trigger — OK");
                    else
                        ImGui::TextColored(ImVec4(1,0,0,1), "  Above trigger — snapping back");
                }
                ImGui::Text("Applied %d times", g_LookGroundApplyCount);
                if (g_LastLookGroundApply) {
                    DWORD since = GetTickCount() - g_LastLookGroundApply;
                    ImGui::Text("Last apply %.0f ms ago", since);
                }

                ImGui::EndTabItem();
            }

            // ---- CAMERA DEBUG ----
            if (ImGui::BeginTabItem("Camera Debug")) {
                g_SGCamera = ResolveSGCamera();

                if (!ValidPtr(g_SGCamera)) {
                    ImGui::TextColored(ImVec4(1,0,0,1), "ASGCamera not resolved this frame.");
                    ImGui::TextDisabled("Wait until you're in-game and spawned.");
                } else {
                    ImGui::Text("ASGCamera @ 0x%llX", (unsigned long long)g_SGCamera);
                    ImGui::SameLine();
                    ImGui::TextColored(ImVec4(0,1,0,1), "(live)");

                    if (ImGui::CollapsingHeader("Live View Cache (real-time)",
                                                ImGuiTreeNodeFlags_DefaultOpen)) {
                        FVector pos = {0,0,0};
                        int32_t p = 0, y = 0, r = 0;
                        float povFov = 0.0f, lockedFov = 0.0f, timeStamp = 0.0f;

                        SafeRead(g_SGCamera + ACAMERA_CAMERACACHE_TIMESTAMP, &timeStamp);
                        SafeReadFVector(g_SGCamera + ACAMERA_POV_LOCATION, &pos);
                        SafeRead(g_SGCamera + ACAMERA_POV_ROTATION_PITCH, &p);
                        SafeRead(g_SGCamera + ACAMERA_POV_ROTATION_YAW, &y);
                        SafeRead(g_SGCamera + ACAMERA_POV_ROTATION_ROLL, &r);
                        SafeRead(g_SGCamera + ACAMERA_POV_FOV, &povFov);
                        SafeRead(g_SGCamera + ACAMERA_LOCKEDFOV, &lockedFov);

                        ImGui::Text("TimeStamp:    %.3f", timeStamp);
                        ImGui::Text("Pos:          %.1f, %.1f, %.1f", pos.x, pos.y, pos.z);
                        ImGui::Text("POV Pitch:    %d  (%.2f deg)", p, p * UU_TO_DEG);
                        ImGui::Text("POV Yaw:      %d  (%.2f deg)", y, y * UU_TO_DEG);
                        ImGui::Text("POV Roll:     %d  (%.2f deg)", r, r * UU_TO_DEG);
                        ImGui::Text("POV FOV:      %.2f", povFov);
                        ImGui::Text("LockedFOV:    %.2f", lockedFov);
                    }

                    if (ImGui::CollapsingHeader("Local Pawn / PC Rotation (real-time)")) {
                        int32_t pcP = 0, pcY = 0, pcR = 0;
                        int32_t lpP = 0, lpY = 0, lpR = 0;

                        if (ValidPtr(g_PC)) {
                            SafeRead(g_PC + ACTOR_ROTATION + 0, &pcP);
                            SafeRead(g_PC + ACTOR_ROTATION + 4, &pcY);
                            SafeRead(g_PC + ACTOR_ROTATION + 8, &pcR);
                        }
                        if (ValidPtr(g_LocalPawn)) {
                            SafeRead(g_LocalPawn + ACTOR_ROTATION + 0, &lpP);
                            SafeRead(g_LocalPawn + ACTOR_ROTATION + 4, &lpY);
                            SafeRead(g_LocalPawn + ACTOR_ROTATION + 8, &lpR);
                        }

                        ImGui::Text("PC  rot: P %d (%.2f)  Y %d (%.2f)  R %d (%.2f)",
                                    pcP, pcP * UU_TO_DEG, pcY, pcY * UU_TO_DEG, pcR, pcR * UU_TO_DEG);
                        ImGui::Text("Pawn rot: P %d (%.2f)  Y %d (%.2f)  R %d (%.2f)",
                                    lpP, lpP * UU_TO_DEG, lpY, lpY * UU_TO_DEG, lpR, lpR * UU_TO_DEG);
                    }

                    if (ImGui::CollapsingHeader("Camera Overrides (writable)")) {
                        float lockedFov = 0.0f;
                        SafeRead(g_SGCamera + ACAMERA_LOCKEDFOV, &lockedFov);
                        if (ImGui::SliderFloat("LockedFOV", &lockedFov, 1.0f, 170.0f, "%.1f"))
                            SafeWriteFloat(g_SGCamera + ACAMERA_LOCKEDFOV, lockedFov);
                        ImGui::SameLine();
                        if (ImGui::SmallButton("Reset##fov"))
                            SafeWriteFloat(g_SGCamera + ACAMERA_LOCKEDFOV, 90.0f);

                        float fadeAmt = 0.0f;
                        SafeRead(g_SGCamera + ACAMERA_FADEAMOUNT, &fadeAmt);
                        if (ImGui::SliderFloat("FadeAmount", &fadeAmt, 0.0f, 1.0f, "%.2f"))
                            SafeWriteFloat(g_SGCamera + ACAMERA_FADEAMOUNT, fadeAmt);

                        float defFov = 0.0f;
                        SafeRead(g_SGCamera + ACAMERA_DEFAULTFOV, &defFov);
                        ImGui::Text("DefaultFOV: %.2f", defFov);
                    }

                    if (ImGui::CollapsingHeader("Camera Contexts (ASGCamera)")) {
                        bool bUseCtx = false;
                        SafeRead(g_SGCamera + ASGCAMERA_BUSECAMERACONTEXTS, &bUseCtx);

                        uintptr_t defCtx = 0, actCtx = 0;
                        SafeRead(g_SGCamera + ASGCAMERA_DEFAULTCONTEXT, &defCtx);
                        SafeRead(g_SGCamera + ASGCAMERA_ACTIVECONTEXT, &actCtx);

                        uintptr_t ctxData = 0;
                        int32_t   ctxCount = 0;
                        SafeRead(g_SGCamera + ASGCAMERA_CAMERACONTEXTS, &ctxData);
                        SafeRead(g_SGCamera + ASGCAMERA_CAMERACONTEXTS + 0x8, &ctxCount);

                        ImGui::Text("Use Contexts: %s", bUseCtx ? "YES" : "no");
                        ImGui::Text("Default ctx:  0x%llX", (unsigned long long)defCtx);
                        ImGui::Text("Active ctx:   0x%llX", (unsigned long long)actCtx);
                        ImGui::Text("Contexts:     %d @ 0x%llX",
                                    ctxCount, (unsigned long long)ctxData);
                    }

                    if (ImGui::CollapsingHeader("Third Person")) {
                        float dist = 0.0f;
                        int32_t tpP = 0, tpY = 0, tpR = 0;
                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_DISTANCE, &dist);
                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_ROTATION + 0, &tpP);
                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_ROTATION + 4, &tpY);
                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_ROTATION + 8, &tpR);

                        ImGui::Text("Distance: %.1f", dist);
                        ImGui::Text("Rot: P %.2f  Y %.2f  R %.2f",
                                    tpP * UU_TO_DEG, tpY * UU_TO_DEG, tpR * UU_TO_DEG);
                    }

                    if (ImGui::CollapsingHeader("First Person Debug")) {
                        float   fpDist = 0.0f;
                        FVector fpOff = {0,0,0};
                        int32_t fpP = 0, fpY = 0, fpR = 0;

                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGDIST, &fpDist);
                        SafeReadFVector(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGOFFSET, &fpOff);
                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGROT + 0, &fpP);
                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGROT + 4, &fpY);
                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGROT + 8, &fpR);

                        ImGui::Text("Distance: %.2f", fpDist);
                        ImGui::Text("Offset: %.2f, %.2f, %.2f", fpOff.x, fpOff.y, fpOff.z);
                        ImGui::Text("Rot: P %.2f  Y %.2f  R %.2f",
                                    fpP * UU_TO_DEG, fpY * UU_TO_DEG, fpR * UU_TO_DEG);
                    }

                    ImGui::Separator();
                    ImGui::TextColored(ImVec4(0.5f,1,1,1), "Snapshot");

                    if (ImGui::Button("Copy All", ImVec2(-1, 30))) {
                        char* w = g_CameraDump;
                        size_t rem = sizeof(g_CameraDump);
                        auto app = [&](const char* fmt, ...) {
                            if (rem < 8) return;
                            va_list ap; va_start(ap, fmt);
                            int n = _vsnprintf_s(w, rem, _TRUNCATE, fmt, ap);
                            va_end(ap);
                            if (n > 0) { w += n; rem -= n; }
                        };

                        app("=== ASGCamera Dump ===\n");
                        app("base=0x%llX  pc=0x%llX  pawn=0x%llX\n",
                            (unsigned long long)g_Base,
                            (unsigned long long)g_PC,
                            (unsigned long long)g_LocalPawn);
                        app("cam=0x%llX\n", (unsigned long long)g_SGCamera);

                        FVector pos = {0,0,0};
                        int32_t p = 0, y = 0, r = 0;
                        float povFov = 0, lockedFov = 0, defFov = 0, timeStamp = 0;
                        SafeRead(g_SGCamera + ACAMERA_CAMERACACHE_TIMESTAMP, &timeStamp);
                        SafeReadFVector(g_SGCamera + ACAMERA_POV_LOCATION, &pos);
                        SafeRead(g_SGCamera + ACAMERA_POV_ROTATION_PITCH, &p);
                        SafeRead(g_SGCamera + ACAMERA_POV_ROTATION_YAW, &y);
                        SafeRead(g_SGCamera + ACAMERA_POV_ROTATION_ROLL, &r);
                        SafeRead(g_SGCamera + ACAMERA_POV_FOV, &povFov);
                        SafeRead(g_SGCamera + ACAMERA_LOCKEDFOV, &lockedFov);
                        SafeRead(g_SGCamera + ACAMERA_DEFAULTFOV, &defFov);

                        app("[CameraCache]\n");
                        app("  TimeStamp=%.3f\n", timeStamp);
                        app("  POV.Location=(%.3f, %.3f, %.3f)\n", pos.x, pos.y, pos.z);
                        app("  POV.Rotation.Pitch=%d (%.4f deg)\n", p, p * UU_TO_DEG);
                        app("  POV.Rotation.Yaw=%d (%.4f deg)\n", y, y * UU_TO_DEG);
                        app("  POV.Rotation.Roll=%d (%.4f deg)\n", r, r * UU_TO_DEG);
                        app("  POV.FOV=%.3f\n", povFov);
                        app("  LockedFOV=%.3f\n", lockedFov);
                        app("  DefaultFOV=%.3f\n", defFov);

                        int32_t pcP=0, pcY=0, pcR=0, lpP=0, lpY=0, lpR=0;
                        if (ValidPtr(g_PC)) {
                            SafeRead(g_PC + ACTOR_ROTATION + 0, &pcP);
                            SafeRead(g_PC + ACTOR_ROTATION + 4, &pcY);
                            SafeRead(g_PC + ACTOR_ROTATION + 8, &pcR);
                        }
                        if (ValidPtr(g_LocalPawn)) {
                            SafeRead(g_LocalPawn + ACTOR_ROTATION + 0, &lpP);
                            SafeRead(g_LocalPawn + ACTOR_ROTATION + 4, &lpY);
                            SafeRead(g_LocalPawn + ACTOR_ROTATION + 8, &lpR);
                        }
                        app("[Rotations @ +0x33c]\n");
                        app("  PC   P=%d (%.4f deg) Y=%d (%.4f deg) R=%d (%.4f deg)\n",
                            pcP, pcP*UU_TO_DEG, pcY, pcY*UU_TO_DEG, pcR, pcR*UU_TO_DEG);
                        app("  Pawn P=%d (%.4f deg) Y=%d (%.4f deg) R=%d (%.4f deg)\n",
                            lpP, lpP*UU_TO_DEG, lpY, lpY*UU_TO_DEG, lpR, lpR*UU_TO_DEG);

                        float   tpDist = 0;
                        int32_t tpP=0, tpY=0, tpR=0;
                        float   fpDist = 0;
                        FVector fpOff = {0,0,0};
                        int32_t fpP=0, fpY=0, fpR=0;
                        bool    bUseCtx = false;
                        uintptr_t defCtx=0, actCtx=0, ctxData=0;
                        int32_t   ctxCount=0;

                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_DISTANCE, &tpDist);
                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_ROTATION + 0, &tpP);
                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_ROTATION + 4, &tpY);
                        SafeRead(g_SGCamera + ASGCAMERA_THIRDPERSON_ROTATION + 8, &tpR);
                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGDIST, &fpDist);
                        SafeReadFVector(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGOFFSET, &fpOff);
                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGROT + 0, &fpP);
                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGROT + 4, &fpY);
                        SafeRead(g_SGCamera + ASGCAMERA_FIRSTPERSON_DEBUGROT + 8, &fpR);
                        SafeRead(g_SGCamera + ASGCAMERA_BUSECAMERACONTEXTS, &bUseCtx);
                        SafeRead(g_SGCamera + ASGCAMERA_DEFAULTCONTEXT, &defCtx);
                        SafeRead(g_SGCamera + ASGCAMERA_ACTIVECONTEXT, &actCtx);
                        SafeRead(g_SGCamera + ASGCAMERA_CAMERACONTEXTS, &ctxData);
                        SafeRead(g_SGCamera + ASGCAMERA_CAMERACONTEXTS + 0x8, &ctxCount);

                        app("[ASGCamera 3P]\n");
                        app("  m_ThirdPersonCameraDistance=%.3f\n", tpDist);
                        app("  m_ThirdPersonCameraRotation P=%d Y=%d R=%d\n", tpP, tpY, tpR);

                        app("[ASGCamera 1P debug]\n");
                        app("  Distance=%.3f\n", fpDist);
                        app("  Offset=(%.3f, %.3f, %.3f)\n", fpOff.x, fpOff.y, fpOff.z);
                        app("  Rotation P=%d (%.4f deg) Y=%d (%.4f deg) R=%d (%.4f deg)\n",
                            fpP, fpP*UU_TO_DEG, fpY, fpY*UU_TO_DEG, fpR, fpR*UU_TO_DEG);

                        app("[ASGCamera contexts]\n");
                        app("  bUseCameraContexts=%s\n", bUseCtx ? "true" : "false");
                        app("  DefaultContext=0x%llX\n", (unsigned long long)defCtx);
                        app("  ActiveContext=0x%llX\n",  (unsigned long long)actCtx);
                        app("  CameraContexts count=%d data=0x%llX\n",
                            ctxCount, (unsigned long long)ctxData);

                        uintptr_t sgPawn=0, viewTarget=0;
                        SafeRead(g_PC + 0x17a8, &sgPawn);
                        SafeRead(sgPawn + 0x1df8, &viewTarget);
                        app("[Chain]\n");
                        app("  PC+0x17a8 -> SGPawn=0x%llX\n", (unsigned long long)sgPawn);
                        app("  SGPawn+0x1df8 -> ViewTarget=0x%llX\n", (unsigned long long)viewTarget);
                        app("  ViewTarget+0x18e4 -> ASGCamera=0x%llX\n",
                            (unsigned long long)g_SGCamera);

                        if (p < 0) {
                            g_LookGroundPitch = p;
                            g_LookGroundCaptured = true;
                            g_LookGroundRecoilTrig = p + (int32_t)(5.0f / UU_TO_DEG);
                            app("[Ground-Capture]\n");
                            app("  Captured POV pitch=%d (%.4f deg) as ground-look pitch.\n",
                                p, p * UU_TO_DEG);
                            app("  Set recoil trigger to %d (%.4f deg).\n",
                                g_LookGroundRecoilTrig, g_LookGroundRecoilTrig * UU_TO_DEG);
                        } else {
                            app("[Ground-Capture]\n");
                            app("  POV pitch is %d (>= 0). Look down and Copy All again.\n", p);
                        }

                        app("=== end ===\n");
                        ImGui::SetClipboardText(g_CameraDump);
                    }

                    ImGui::InputTextMultiline("##camdump",
                        g_CameraDump, sizeof(g_CameraDump),
                        ImVec2(-1, 200),
                        ImGuiInputTextFlags_ReadOnly);
                }

                ImGui::EndTabItem();
            }

            // ---- CONFIG ----
            if (ImGui::BeginTabItem("Config")) {
                if (ImGui::Button("Save Config", ImVec2(-1, 26))) SaveConfig();
                if (ImGui::Button("Load Config", ImVec2(-1, 26))) LoadConfig();
                ImGui::EndTabItem();
            }

            ImGui::EndTabBar();
        }

        ImGui::End();
    }
    ImGui::Render();
}

// ============ DX9 ============
HRESULT WINAPI hkEndScene(IDirect3DDevice9* d) {
    if (!bInit) {
        g_pDevice = d;
        hWindow = FindWindowA("LaunchUnrealUWindowsClient", NULL);
        if (!hWindow) hWindow = FindWindowA(NULL, "Dirty Bomb");
        if (!hWindow) hWindow = GetForegroundWindow();
        if (hWindow) {
            oWndProc = (WNDPROC)SetWindowLongPtr(hWindow, GWLP_WNDPROC, (LONG_PTR)WndProc);
        }
        ImGui::CreateContext();
        ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        if (hWindow) ImGui_ImplWin32_Init(hWindow);
        ImGui_ImplDX9_Init(d);
        bInit = true;
    }

    HRESULT coop = d->TestCooperativeLevel();
    if (coop == D3DERR_DEVICELOST || coop == D3DERR_DEVICENOTRESET) {
        return oEndScene(d);
    }

    static bool isPressed = false;
    if (GetAsyncKeyState(VK_INSERT) & 0x8000) {
        if (!isPressed) { bShowMenu = !bShowMenu; isPressed = true; }
    } else isPressed = false;

    RunGameLogic();

    IDirect3DStateBlock9* stateBlock = nullptr;
    if (d->CreateStateBlock(D3DSBT_ALL, &stateBlock) == S_OK) {
        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        DrawGUI();
        DrawESP();
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
        stateBlock->Apply();
        stateBlock->Release();
    } else {
        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        DrawGUI();
        DrawESP();
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
    }

    return oEndScene(d);
}

HRESULT WINAPI hkReset(IDirect3DDevice9* d, D3DPRESENT_PARAMETERS* pp) {
    if (bInit) ImGui_ImplDX9_InvalidateDeviceObjects();
    HRESULT hr = oReset(d, pp);
    if (SUCCEEDED(hr) && bInit) {
        g_pDevice = d;
        ImGui_ImplDX9_CreateDeviceObjects();
    }
    return hr;
}

// ============ ENTRY ============
static bool g_Injected = false;

DWORD WINAPI MainThread(LPVOID lp) {
    g_Base = (uintptr_t)GetModuleHandleA(NULL);

    AllocConsole();
    FILE* f;
    freopen_s(&f, "CONOUT$", "w", stdout);
    if (HWND con = GetConsoleWindow()) ShowWindow(con, SW_HIDE);

    LoadConfig();
    printf("[*] Dirty Bomb Mod Loader v9.13 (Look-Ground Active + Camera Debug)\n");

    HWND hw = NULL;
    while (!hw) {
        hw = FindWindowA("LaunchUnrealUWindowsClient", NULL);
        if (!hw) hw = FindWindowA(NULL, "Dirty Bomb");
        Sleep(500);
    }

    IDirect3D9* d9 = Direct3DCreate9(D3D_SDK_VERSION);
    if (!d9) return 0;

    D3DPRESENT_PARAMETERS dp = {0};
    dp.Windowed = TRUE;
    dp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    dp.hDeviceWindow = hw;

    IDirect3DDevice9* dev = NULL;
    if (SUCCEEDED(d9->CreateDevice(0, D3DDEVTYPE_HAL, hw,
                                   D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                   &dp, &dev))) {
        void** vt = *(void***)dev;
        oEndScene = (EndScene_t)vt[D3D9_ENDSCENE_INDEX];
        oReset    = (Reset_t)vt[D3D9_RESET_INDEX];

        DWORD old;
        VirtualProtect(&vt[D3D9_ENDSCENE_INDEX], sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        vt[D3D9_ENDSCENE_INDEX] = (void*)hkEndScene;
        VirtualProtect(&vt[D3D9_ENDSCENE_INDEX], sizeof(void*), old, &old);

        VirtualProtect(&vt[D3D9_RESET_INDEX], sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        vt[D3D9_RESET_INDEX] = (void*)hkReset;
        VirtualProtect(&vt[D3D9_RESET_INDEX], sizeof(void*), old, &old);

        dev->Release();
    }
    d9->Release();
    return 0;
}

extern "C" __declspec(dllexport) BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID l) {
    if (r == 1 && !g_Injected) {
        g_Injected = true;
        CreateThread(0, 0, MainThread, 0, 0, NULL);
    }
    return 1;
}

extern "C" {
    __declspec(dllexport) BOOL WINAPI GetFileVersionInfoA(LPCSTR l, DWORD d, DWORD dl, LPVOID lp) { return FALSE; }
    __declspec(dllexport) BOOL WINAPI GetFileVersionInfoW(LPCWSTR l, DWORD d, DWORD dl, LPVOID lp) { return FALSE; }
    __declspec(dllexport) DWORD WINAPI GetFileVersionInfoSizeA(LPCSTR l, DWORD* lp) { return 0; }
    __declspec(dllexport) DWORD WINAPI GetFileVersionInfoSizeW(LPCWSTR l, DWORD* lp) { return 0; }
    __declspec(dllexport) BOOL WINAPI VerQueryValueA(LPCVOID p, LPCSTR l, LPVOID* pp, PUINT pu) { return FALSE; }
    __declspec(dllexport) BOOL WINAPI VerQueryValueW(LPCVOID p, LPCWSTR l, LPVOID* pp, PUINT pu) { return FALSE; }
}
